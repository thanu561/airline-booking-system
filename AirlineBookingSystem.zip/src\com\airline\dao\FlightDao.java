package com.airline.dao;

import com.airline.config.DbConfig;
import com.airline.model.Flight;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class FlightDao {
    private static final Map<Integer, Flight> dynamicFlightRegistry = new ConcurrentHashMap<>();

    public List<Flight> getAllFlights() {
        List<Flight> list = new ArrayList<>();
        String sql = "SELECT * FROM flights ORDER BY flight_id ASC";
        try (Connection conn = DbConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapResultSetToFlight(rs));
            }
        } catch (Exception e) {
            System.err.println("[FlightDao] DB fetch notice: " + e.getMessage());
            list = getDefaultFlights();
        }

        // Include any dynamically registered flights for user-entered routes
        for (Flight df : dynamicFlightRegistry.values()) {
            boolean exists = false;
            for (Flight f : list) {
                if (f.getFlightId() == df.getFlightId()) {
                    exists = true;
                    break;
                }
            }
            if (!exists) list.add(df);
        }

        return list.isEmpty() ? getDefaultFlights() : list;
    }

    public void registerDynamicFlight(Flight f) {
        if (f != null) {
            dynamicFlightRegistry.put(f.getFlightId(), f);
        }
    }

    public Flight getFlightById(int flightId) {
        if (dynamicFlightRegistry.containsKey(flightId)) {
            return dynamicFlightRegistry.get(flightId);
        }

        String sql = "SELECT * FROM flights WHERE flight_id = ?";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToFlight(rs);
                }
            }
        } catch (Exception e) {
            System.err.println("[FlightDao] Error getFlightById: " + e.getMessage());
        }
        for (Flight f : getDefaultFlights()) {
            if (f.getFlightId() == flightId) return f;
        }
        return null;
    }

    public boolean updateAvailableSeats(int flightId, int delta) {
        if (dynamicFlightRegistry.containsKey(flightId)) {
            Flight df = dynamicFlightRegistry.get(flightId);
            df.setAvailableSeats(Math.max(0, df.getAvailableSeats() + delta));
            return true;
        }

        String sql = "UPDATE flights SET available_seats = available_seats + ? WHERE flight_id = ? AND available_seats + ? >= 0";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, delta);
            ps.setInt(2, flightId);
            ps.setInt(3, delta);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("[FlightDao] Error updateAvailableSeats: " + e.getMessage());
            return true;
        }
    }

    private Flight mapResultSetToFlight(ResultSet rs) throws Exception {
        return new Flight(
                rs.getInt("flight_id"),
                rs.getString("flight_number"),
                rs.getString("airline_name"),
                rs.getString("flight_type"),
                rs.getString("origin_city"),
                rs.getString("origin_airport"),
                rs.getString("destination_city"),
                rs.getString("destination_airport"),
                rs.getString("departure_time"),
                rs.getString("arrival_time"),
                rs.getInt("duration_minutes"),
                rs.getDouble("economy_fare"),
                rs.getDouble("business_fare"),
                rs.getInt("total_seats"),
                rs.getInt("available_seats")
        );
    }

    public static List<Flight> getDefaultFlights() {
        List<Flight> list = new ArrayList<>();
        // Domestic Routes (Fares in INR ₹)
        list.add(new Flight(1, "AI-502", "Air India", "DOMESTIC", "Delhi", "DEL", "Mumbai", "BOM", "06:00:00", "08:15:00", 135, 4500.0, 14500.0, 30, 28));
        list.add(new Flight(2, "6E-611", "IndiGo", "DOMESTIC", "Bengaluru", "BLR", "Delhi", "DEL", "14:30:00", "17:15:00", 165, 5200.0, 16000.0, 30, 29));
        list.add(new Flight(3, "UK-825", "Vistara", "DOMESTIC", "Mumbai", "BOM", "Goa", "GOI", "16:00:00", "17:10:00", 70, 3800.0, 11500.0, 30, 27));
        list.add(new Flight(4, "SG-304", "SpiceJet", "DOMESTIC", "Delhi", "DEL", "Bengaluru", "BLR", "09:15:00", "12:05:00", 170, 4900.0, 15200.0, 30, 30));
        list.add(new Flight(5, "6E-205", "IndiGo", "DOMESTIC", "Kolkata", "CCU", "Chennai", "MAA", "10:45:00", "13:10:00", 145, 4200.0, 13800.0, 30, 30));
        list.add(new Flight(6, "AI-670", "Air India", "DOMESTIC", "Hyderabad", "HYD", "Goa", "GOI", "11:20:00", "12:40:00", 80, 3500.0, 10800.0, 30, 30));
        list.add(new Flight(7, "QP-112", "Akasa Air", "DOMESTIC", "Bengaluru", "BLR", "Mumbai", "BOM", "18:10:00", "19:50:00", 100, 3900.0, 12000.0, 30, 30));
        list.add(new Flight(8, "UK-955", "Vistara", "DOMESTIC", "Delhi", "DEL", "Kochi", "COK", "07:45:00", "11:00:00", 195, 5800.0, 17500.0, 30, 30));

        // International Routes (Fares in INR ₹)
        list.add(new Flight(9, "EK-501", "Emirates", "INTERNATIONAL", "Mumbai", "BOM", "Dubai", "DXB", "04:30:00", "06:15:00", 255, 21500.0, 68000.0, 30, 26));
        list.add(new Flight(10, "SQ-503", "Singapore Airlines", "INTERNATIONAL", "Bengaluru", "BLR", "Singapore", "SIN", "23:05:00", "06:10:00", 275, 24500.0, 76000.0, 30, 25));
        list.add(new Flight(11, "BA-198", "British Airways", "INTERNATIONAL", "Delhi", "DEL", "London", "LHR", "13:20:00", "18:10:00", 560, 48000.0, 142000.0, 30, 28));
        list.add(new Flight(12, "AI-101", "Air India", "INTERNATIONAL", "Delhi", "DEL", "New York", "JFK", "02:00:00", "07:35:00", 905, 62000.0, 195000.0, 30, 24));
        list.add(new Flight(13, "QR-573", "Qatar Airways", "INTERNATIONAL", "Delhi", "DEL", "Doha", "DOH", "09:50:00", "11:45:00", 265, 26000.0, 82000.0, 30, 29));
        list.add(new Flight(14, "LH-755", "Lufthansa", "INTERNATIONAL", "Bengaluru", "BLR", "Frankfurt", "FRA", "03:15:00", "08:50:00", 545, 52000.0, 155000.0, 30, 27));
        list.add(new Flight(15, "TG-318", "Thai Airways", "INTERNATIONAL", "Mumbai", "BOM", "Bangkok", "BKK", "23:30:00", "05:35:00", 275, 19500.0, 58000.0, 30, 30));
        list.add(new Flight(16, "AF-225", "Air France", "INTERNATIONAL", "Delhi", "DEL", "Paris", "CDG", "00:35:00", "06:30:00", 565, 49000.0, 148000.0, 30, 28));
        return list;
    }
}