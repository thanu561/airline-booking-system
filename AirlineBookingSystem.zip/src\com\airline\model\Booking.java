package com.airline.model;

import java.util.ArrayList;
import java.util.List;

public class Booking {
    private int bookingId;
    private String pnr;
    private int flightId;
    private String travelDate;
    private String travelClass; // ECONOMY or BUSINESS
    private String contactName;
    private String contactEmail;
    private String contactPhone;
    private double totalAmount;
    private String status; // CONFIRMED, WAITING_LIST, CANCELLED
    private Integer wlPosition;
    private String createdAt;

    private Flight flight;
    private List<Passenger> passengers = new ArrayList<>();

    public Booking() {}

    public Booking(int bookingId, String pnr, int flightId, String travelDate, String travelClass,
                   String contactName, String contactEmail, String contactPhone, double totalAmount,
                   String status, Integer wlPosition, String createdAt) {
        this.bookingId = bookingId;
        this.pnr = pnr;
        this.flightId = flightId;
        this.travelDate = travelDate;
        this.travelClass = travelClass;
        this.contactName = contactName;
        this.contactEmail = contactEmail;
        this.contactPhone = contactPhone;
        this.totalAmount = totalAmount;
        this.status = status;
        this.wlPosition = wlPosition;
        this.createdAt = createdAt;
    }

    public int getBookingId() { return bookingId; }
    public void setBookingId(int bookingId) { this.bookingId = bookingId; }

    public String getPnr() { return pnr; }
    public void setPnr(String pnr) { this.pnr = pnr; }

    public int getFlightId() { return flightId; }
    public void setFlightId(int flightId) { this.flightId = flightId; }

    public String getTravelDate() { return travelDate; }
    public void setTravelDate(String travelDate) { this.travelDate = travelDate; }

    public String getTravelClass() { return travelClass; }
    public void setTravelClass(String travelClass) { this.travelClass = travelClass; }

    public String getContactName() { return contactName; }
    public void setContactName(String contactName) { this.contactName = contactName; }

    public String getContactEmail() { return contactEmail; }
    public void setContactEmail(String contactEmail) { this.contactEmail = contactEmail; }

    public String getContactPhone() { return contactPhone; }
    public void setContactPhone(String contactPhone) { this.contactPhone = contactPhone; }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Integer getWlPosition() { return wlPosition; }
    public void setWlPosition(Integer wlPosition) { this.wlPosition = wlPosition; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public Flight getFlight() { return flight; }
    public void setFlight(Flight flight) { this.flight = flight; }

    public List<Passenger> getPassengers() { return passengers; }
    public void setPassengers(List<Passenger> passengers) { this.passengers = passengers; }
}