#!/bin/bash
echo "==================================================="
echo "  Compiling Skyline Airline Booking System..."
echo "==================================================="

mkdir -p build

javac -encoding UTF-8 -cp "lib/mysql-connector-j-8.4.0.jar" -d build src/com/airline/model/*.java src/com/airline/config/*.java src/com/airline/dsa/*.java src/com/airline/dao/*.java src/com/airline/service/*.java src/com/airline/server/*.java src/com/airline/Main.java

if [ $? -eq 0 ]; then
    echo ""
    echo "[SUCCESS] Compilation finished with 0 errors!"
else
    echo ""
    echo "[ERROR] Compilation failed. Please ensure JDK 11+ is installed."
fi