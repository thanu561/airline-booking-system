package com.airline.service;

import com.airline.dao.FlightDao;
import com.airline.dao.SeatDao;
import com.airline.dsa.FlightArray;
import com.airline.dsa.FlightSearchEngine;
import com.airline.dsa.FlightSorter;
import com.airline.model.Flight;
import com.airline.model.Seat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class FlightService {
    private final FlightDao flightDao = new FlightDao();
    private final SeatDao seatDao = new SeatDao();
    private static final AtomicInteger dynamicIdCounter = new AtomicInteger(100);

    public List<Flight> getAllFlights() {
        return flightDao.getAllFlights();
    }

    public Flight getFlightById(int flightId) {
        return flightDao.getFlightById(flightId);
    }

    /**
     * Searches and filters flights using DSA Search Engine and sorts using DSA MergeSort / QuickSort.
     * If user enters custom Source & Destination not yet in catalog, automatically creates scheduled flights!
     */
    public List<Flight> searchFlights(String origin, String destination, String flightType,
                                      String travelClass, String sortBy, boolean ascending, Double maxFare) {
        List<Flight> allFlights = flightDao.getAllFlights();
        Flight[] flightArr = allFlights.toArray(new Flight[0]);

        // 1. DSA Multi-Attribute Filtering
        List<Flight> filteredList = FlightSearchEngine.filterFlights(flightArr, origin, destination, flightType, maxFare, travelClass);

        // 2. Custom Source & Destination on-demand route generation
        if (filteredList.isEmpty() && origin != null && !origin.trim().isEmpty() &&
                destination != null && !destination.trim().isEmpty()) {
            List<Flight> generated = generateCustomRouteFlights(origin.trim(), destination.trim(), flightType, travelClass);
            for (Flight f : generated) {
                flightDao.registerDynamicFlight(f);
                filteredList.add(f);
            }
        }

        Flight[] matchedArr = filteredList.toArray(new Flight[0]);
        if (matchedArr.length <= 1) {
            return filteredList;
        }

        // 3. DSA Sorting Algorithms
        boolean isBusiness = "BUSINESS".equalsIgnoreCase(travelClass);
        if ("price".equalsIgnoreCase(sortBy) || "fare".equalsIgnoreCase(sortBy)) {
            FlightSorter.mergeSortByFare(matchedArr, ascending, isBusiness);
        } else if ("duration".equalsIgnoreCase(sortBy)) {
            FlightSorter.quickSortByDuration(matchedArr, ascending);
        } else if ("time".equalsIgnoreCase(sortBy) || "departure".equalsIgnoreCase(sortBy)) {
            FlightSorter.quickSortByDepartureTime(matchedArr, ascending);
        }

        List<Flight> result = new ArrayList<>();
        for (Flight f : matchedArr) {
            result.add(f);
        }
        return result;
    }

    private List<Flight> generateCustomRouteFlights(String origin, String destination, String flightType, String travelClass) {
        List<Flight> list = new ArrayList<>();
        String origCode = getAirportCode(origin);
        String destCode = getAirportCode(destination);

        boolean isInter = "INTERNATIONAL".equalsIgnoreCase(flightType) || isInternationalCity(origin) || isInternationalCity(destination);
        String cat = isInter ? "INTERNATIONAL" : "DOMESTIC";

        double baseEcon = isInter ? 28000.0 : 4500.0;
        double baseBiz = isInter ? 85000.0 : 14000.0;

        int id1 = dynamicIdCounter.incrementAndGet();
        Flight f1 = new Flight(id1, "AI-" + (200 + (id1 % 700)), "Air India", cat,
                capitalize(origin), origCode, capitalize(destination), destCode,
                "07:30:00", "10:15:00", isInter ? 360 : 165, baseEcon, baseBiz, 30, 29);
        list.add(f1);

        int id2 = dynamicIdCounter.incrementAndGet();
        Flight f2 = new Flight(id2, "6E-" + (500 + (id2 % 400)), "IndiGo", cat,
                capitalize(origin), origCode, capitalize(destination), destCode,
                "15:45:00", "18:20:00", isInter ? 380 : 155, baseEcon + 400.0, baseBiz + 1500.0, 30, 27);
        list.add(f2);

        int id3 = dynamicIdCounter.incrementAndGet();
        Flight f3 = new Flight(id3, "UK-" + (800 + (id3 % 150)), "Vistara", cat,
                capitalize(origin), origCode, capitalize(destination), destCode,
                "20:10:00", "22:50:00", isInter ? 370 : 160, baseEcon + 900.0, baseBiz + 2500.0, 30, 30);
        list.add(f3);

        return list;
    }

    private String getAirportCode(String city) {
        if (city == null || city.isEmpty()) return "APX";
        String clean = city.trim().toUpperCase();
        if (clean.startsWith("DELHI")) return "DEL";
        if (clean.startsWith("MUMBAI")) return "BOM";
        if (clean.startsWith("BENGALURU") || clean.startsWith("BANGALORE")) return "BLR";
        if (clean.startsWith("KOLKATA")) return "CCU";
        if (clean.startsWith("CHENNAI")) return "MAA";
        if (clean.startsWith("HYDERABAD")) return "HYD";
        if (clean.startsWith("GOA")) return "GOI";
        if (clean.startsWith("KOCHI") || clean.startsWith("COCHIN")) return "COK";
        if (clean.startsWith("PUNE")) return "PNQ";
        if (clean.startsWith("JAIPUR")) return "JAI";
        if (clean.startsWith("DUBAI")) return "DXB";
        if (clean.startsWith("SINGAPORE")) return "SIN";
        if (clean.startsWith("LONDON")) return "LHR";
        if (clean.startsWith("NEW YORK")) return "JFK";
        if (clean.startsWith("PARIS")) return "CDG";
        if (clean.startsWith("TOKYO")) return "NRT";
        if (clean.startsWith("BANGKOK")) return "BKK";
        if (clean.length() >= 3) return clean.substring(0, 3);
        return clean + "X";
    }

    private boolean isInternationalCity(String city) {
        if (city == null) return false;
        String c = city.toLowerCase();
        return c.contains("dubai") || c.contains("london") || c.contains("singapore") ||
                c.contains("new york") || c.contains("paris") || c.contains("tokyo") ||
                c.contains("bangkok") || c.contains("frankfurt") || c.contains("doha") ||
                c.contains("chicago") || c.contains("san francisco");
    }

    private String capitalize(String str) {
        if (str == null || str.isEmpty()) return "";
        return Character.toUpperCase(str.charAt(0)) + str.substring(1).toLowerCase();
    }

    public Flight findFlightByBinarySearch(int flightId) {
        List<Flight> allFlights = flightDao.getAllFlights();
        Flight[] arr = allFlights.toArray(new Flight[0]);
        java.util.Arrays.sort(arr, (a, b) -> Integer.compare(a.getFlightId(), b.getFlightId()));
        return FlightSearchEngine.binarySearchById(arr, flightId);
    }

    public List<Flight> findFlightsUnderBudgetBinarySearch(double maxBudget) {
        List<Flight> allFlights = flightDao.getAllFlights();
        Flight[] arr = allFlights.toArray(new Flight[0]);
        FlightSorter.mergeSortByFare(arr, true, false);
        return FlightSearchEngine.binarySearchByMaxFare(arr, maxBudget);
    }

    public List<Seat> getFlightSeats(int flightId) {
        return seatDao.getSeatsByFlightId(flightId);
    }
}