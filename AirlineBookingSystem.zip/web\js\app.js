// =========================================================================
// Skyline Airways - Client Application Logic (INR Currency & Dynamic Routes)
// =========================================================================

const API_BASE = window.location.origin;

// State Management
let currentFlights = [];
let selectedFlight = null;
let selectedSeatNumber = null;
let selectedMeal = null;
let allMeals = [];
let lastConfirmedPnr = null;

// Currency Formatter for Indian Rupees (₹)
function formatINR(amount) {
    if (isNaN(amount)) return "₹0.00";
    return "₹" + Number(amount).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
    const dateInput = document.getElementById("travel-date");
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + 3);
    dateInput.value = futureDate.toISOString().split("T")[0];

    handleFlightSearch();
    loadMeals();
    loadNotifications();

    setInterval(loadNotifications, 15000);
});

// =========================================================================
// 1. NAVIGATION & TAB SWITCHING
// =========================================================================
function switchTab(tabId) {
    document.querySelectorAll(".tab-content").forEach(el => el.classList.remove("active"));
    document.querySelectorAll(".nav-btn").forEach(el => el.classList.remove("active"));

    const targetTab = document.getElementById(tabId);
    if (targetTab) {
        targetTab.classList.add("active");
    }

    const clickedBtn = Array.from(document.querySelectorAll(".nav-btn")).find(btn =>
        btn.getAttribute("onclick") && btn.getAttribute("onclick").includes(tabId)
    );
    if (clickedBtn) {
        clickedBtn.classList.add("active");
    }
}

function toggleNotifications() {
    const drawer = document.getElementById("notif-drawer");
    drawer.classList.toggle("open");
    if (drawer.classList.contains("open")) {
        loadNotifications();
    }
}

// =========================================================================
// 2. FLIGHT SEARCH & FILTERING (Source, Destination, Class, DSA Sorter)
// =========================================================================
function cleanCityInput(val) {
    if (!val) return "";
    // If input is like "Delhi (DEL)", extract "Delhi"
    const parenIdx = val.indexOf("(");
    if (parenIdx > 0) {
        return val.substring(0, parenIdx).trim();
    }
    return val.trim();
}

async function handleFlightSearch(event) {
    if (event) event.preventDefault();

    const originRaw = document.getElementById("origin-input").value;
    const destRaw = document.getElementById("dest-input").value;
    const origin = cleanCityInput(originRaw);
    const destination = cleanCityInput(destRaw);

    const flightType = document.querySelector('input[name="flightType"]:checked').value;
    const travelClass = document.querySelector('input[name="travelClass"]:checked').value;
    const sortBy = document.getElementById("sort-select").value;

    const params = new URLSearchParams({
        origin: origin,
        destination: destination,
        type: flightType,
        class: travelClass,
        sort: sortBy,
        order: "asc"
    });

    const container = document.getElementById("flights-container");
    container.innerHTML = `<div class="empty-state"><p>Searching flights across route networks...</p></div>`;

    try {
        const res = await fetch(`${API_BASE}/api/flights?${params.toString()}`);
        if (!res.ok) throw new Error("Failed to fetch flights");
        const flights = await res.json();
        currentFlights = flights;
        renderFlights(flights, travelClass);
    } catch (err) {
        console.error("Flight search error:", err);
        container.innerHTML = `<div class="empty-state"><p style="color:var(--danger)">Unable to load flights. Please ensure backend server is active.</p></div>`;
    }
}

function renderFlights(flights, travelClass) {
    const container = document.getElementById("flights-container");
    const countBadge = document.getElementById("flight-count-badge");
    countBadge.textContent = `${flights.length} Found`;

    if (!flights || flights.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1;">
                <p>No flights found for this specific query. Try adjusting your Source or Destination.</p>
            </div>
        `;
        return;
    }

    const isBusiness = travelClass === "BUSINESS";

    container.innerHTML = flights.map(f => {
        const fare = isBusiness ? f.businessFare : f.economyFare;
        const durationHours = Math.floor(f.durationMinutes / 60);
        const durationMins = f.durationMinutes % 60;
        const durationFormatted = `${durationHours}h ${durationMins > 0 ? durationMins + 'm' : ''}`;

        let seatStatusClass = "seats-available";
        let seatStatusText = `${f.availableSeats} Seats Available`;
        let btnText = "Select & Choose Seats";
        let btnClass = "btn-primary";

        if (f.availableSeats <= 0) {
            seatStatusClass = "seats-full";
            seatStatusText = "Capacity Full (Waitlist Open)";
            btnText = "Join Waiting List";
            btnClass = "btn-outline";
        } else if (f.availableSeats <= 3) {
            seatStatusClass = "seats-low";
            seatStatusText = `Only ${f.availableSeats} Seats Left!`;
        }

        return `
            <div class="flight-card">
                <div>
                    <div class="card-top">
                        <div>
                            <div class="airline-badge">${f.airlineName}</div>
                            <span class="flight-num">${f.flightNumber}</span>
                        </div>
                        <span class="type-tag ${f.flightType.toLowerCase()}">${f.flightType}</span>
                    </div>

                    <div class="route-info">
                        <div class="route-point">
                            <div class="airport-code">${f.originAirport}</div>
                            <div class="city-name">${f.originCity}</div>
                            <div class="flight-time">${f.departureTime.substring(0, 5)}</div>
                        </div>

                        <div class="route-path">
                            <span class="duration-text">${durationFormatted} (Non-stop)</span>
                            <div class="path-line"></div>
                        </div>

                        <div class="route-point">
                            <div class="airport-code">${f.destinationAirport}</div>
                            <div class="city-name">${f.destinationCity}</div>
                            <div class="flight-time">${f.arrivalTime.substring(0, 5)}</div>
                        </div>
                    </div>
                </div>

                <div class="card-bottom">
                    <div class="price-box">
                        <span class="price-label">${isBusiness ? "Business" : "Economy"} Fare</span>
                        <span class="price-amount">${formatINR(fare)}</span>
                        <span class="seats-status ${seatStatusClass}">● ${seatStatusText}</span>
                    </div>
                    <button class="btn btn-sm ${btnClass}" onclick="openBookingModal(${f.flightId})">
                        ${btnText}
                    </button>
                </div>
            </div>
        `;
    }).join("");
}

function swapOriginDestination() {
    const origin = document.getElementById("origin-input");
    const dest = document.getElementById("dest-input");
    const temp = origin.value;
    origin.value = dest.value;
    dest.value = temp;
    handleFlightSearch();
}

function handleClassChange() {
    handleFlightSearch();
}

function resetSearchFilters() {
    document.getElementById("origin-input").value = "";
    document.getElementById("dest-input").value = "";
    document.getElementById("sort-select").value = "price";
    document.querySelector('input[name="flightType"][value="ALL"]').checked = true;
    handleFlightSearch();
}

// =========================================================================
// 3. SEAT MAP (DSA ARRAY / MATRIX) & MEAL PICKER
// =========================================================================
async function openBookingModal(flightId) {
    selectedFlight = currentFlights.find(f => f.flightId === flightId);
    if (!selectedFlight) return;

    selectedSeatNumber = null;
    selectedMeal = allMeals.length > 0 ? allMeals[0] : null;

    const travelClass = document.querySelector('input[name="travelClass"]:checked').value;
    const travelDate = document.getElementById("travel-date").value;

    document.getElementById("modal-flight-title").textContent =
        `${selectedFlight.airlineName} (${selectedFlight.flightNumber}) - ${selectedFlight.originCity} to ${selectedFlight.destinationCity}`;
    document.getElementById("modal-flight-subtitle").textContent =
        `Date: ${travelDate} | Class: ${travelClass} | Duration: ${Math.floor(selectedFlight.durationMinutes / 60)}h ${selectedFlight.durationMinutes % 60}m`;

    document.getElementById("modal-flight-summary").innerHTML = `
        <span><strong>Flight:</strong> ${selectedFlight.flightNumber}</span>
        <span><strong>Route:</strong> ${selectedFlight.originAirport} → ${selectedFlight.destinationAirport}</span>
        <span><strong>Departure:</strong> ${selectedFlight.departureTime}</span>
        <span><strong>Status:</strong> ${selectedFlight.availableSeats > 0 ? `${selectedFlight.availableSeats} Seats Available` : "Full (Waitlist)"}</span>
    `;

    document.getElementById("calc-class-name").textContent = travelClass;
    document.getElementById("selected-seat-msg").innerHTML = `Selected Seat: <strong>None (Auto-allocated if unselected)</strong>`;

    await loadSeatMap(flightId, travelClass);
    renderMeals();
    handleAgePriorityCheck();
    updatePriceCalculation();

    const submitBtn = document.getElementById("btn-submit-booking");
    if (selectedFlight.availableSeats <= 0) {
        submitBtn.textContent = "Join Waiting List (Capacity Full)";
        submitBtn.className = "btn btn-outline btn-block";
    } else {
        submitBtn.textContent = "Confirm Reservation";
        submitBtn.className = "btn btn-success btn-block";
    }

    document.getElementById("booking-modal").classList.add("active");
}

function closeBookingModal() {
    document.getElementById("booking-modal").classList.remove("active");
}

async function loadSeatMap(flightId, travelClass) {
    const businessGrid = document.getElementById("business-seat-grid");
    const economyGrid = document.getElementById("economy-seat-grid");
    businessGrid.innerHTML = "Loading seats...";
    economyGrid.innerHTML = "Loading seats...";

    try {
        const res = await fetch(`${API_BASE}/api/seats?flightId=${flightId}`);
        const seats = await res.json();

        const businessSeats = seats.filter(s => s.seatClass === "BUSINESS");
        const economySeats = seats.filter(s => s.seatClass === "ECONOMY");

        businessGrid.innerHTML = businessSeats.map(s => renderSeatButton(s)).join("");
        economyGrid.innerHTML = economySeats.map(s => renderSeatButton(s)).join("");
    } catch (err) {
        console.error("Error loading seats:", err);
    }
}

function renderSeatButton(seat) {
    const isBooked = seat.isBooked;
    const isSelected = seat.seatNumber === selectedSeatNumber;
    let cls = "seat-btn";
    if (isBooked) cls += " booked";
    if (isSelected) cls += " selected";

    return `
        <button type="button" class="${cls}"
                ${isBooked ? "disabled" : ""}
                onclick="selectSeat('${seat.seatNumber}', '${seat.seatClass}')"
                title="${seat.seatNumber} (${seat.seatClass}) ${isBooked ? '- Booked' : '- Available'}">
            ${seat.seatNumber}
        </button>
    `;
}

function selectSeat(seatNumber, seatClass) {
    selectedSeatNumber = seatNumber;
    document.querySelectorAll(".seat-btn").forEach(btn => {
        btn.classList.remove("selected");
        if (btn.textContent.trim() === seatNumber) {
            btn.classList.add("selected");
        }
    });

    document.getElementById("selected-seat-msg").innerHTML =
        `Selected Seat: <strong style="color:var(--success)">${seatNumber} (${seatClass})</strong>`;
    showToast(`Seat ${seatNumber} selected`, "info");
}

// =========================================================================
// 4. MEAL SELECTION WITH FIXED PRICES IN INR
// =========================================================================
async function loadMeals() {
    try {
        const res = await fetch(`${API_BASE}/api/meals`);
        allMeals = await res.json();
    } catch (err) {
        console.error("Error fetching meals:", err);
    }
}

function renderMeals() {
    const container = document.getElementById("meals-container");
    if (!allMeals || allMeals.length === 0) {
        container.innerHTML = `<p>Meals catalog loading...</p>`;
        return;
    }

    container.innerHTML = allMeals.map(m => {
        const isSelected = selectedMeal && selectedMeal.mealId === m.mealId;
        const typeClass = m.mealType.toLowerCase().replace("_", "-");

        return `
            <div class="meal-card ${isSelected ? "selected" : ""}" onclick="selectMeal(${m.mealId})">
                <div class="meal-info">
                    <h5>
                        ${m.mealName}
                        <span class="meal-badge ${typeClass}">${m.mealType}</span>
                    </h5>
                    <p class="meal-desc">${m.description}</p>
                </div>
                <div class="meal-price">${m.price === 0 ? "FREE" : formatINR(m.price)}</div>
            </div>
        `;
    }).join("");
}

function selectMeal(mealId) {
    selectedMeal = allMeals.find(m => m.mealId === mealId);
    renderMeals();
    updatePriceCalculation();
}

// =========================================================================
// 5. AUTOMATIC TOTAL CALCULATION IN INR (₹)
// =========================================================================
function handleAgePriorityCheck() {
    const ageInput = document.getElementById("pass-age");
    const priorityBox = document.getElementById("pass-priority");
    const seniorAlert = document.getElementById("senior-alert");

    const age = parseInt(ageInput.value) || 0;
    if (age >= 60) {
        priorityBox.checked = true;
        seniorAlert.style.display = "block";
    } else {
        seniorAlert.style.display = "none";
    }
}

function updatePriceCalculation() {
    if (!selectedFlight) return;

    const travelClass = document.querySelector('input[name="travelClass"]:checked').value;
    const baseFare = travelClass === "BUSINESS" ? selectedFlight.businessFare : selectedFlight.economyFare;
    const mealPrice = selectedMeal ? selectedMeal.price : 0.0;
    const grandTotal = baseFare + mealPrice;

    document.getElementById("calc-base-fare").textContent = formatINR(baseFare);
    document.getElementById("calc-meal-name").textContent = selectedMeal ? selectedMeal.mealName : "None";
    document.getElementById("calc-meal-fee").textContent = mealPrice === 0 ? "₹0.00" : `+${formatINR(mealPrice)}`;
    document.getElementById("calc-grand-total").textContent = formatINR(grandTotal);
}

// =========================================================================
// 6. CONFIRM BOOKING TRANSACTION
// =========================================================================
async function handleConfirmBooking(event) {
    event.preventDefault();

    if (!selectedFlight) return;

    const travelClass = document.querySelector('input[name="travelClass"]:checked').value;
    const travelDate = document.getElementById("travel-date").value;
    const fullName = document.getElementById("pass-name").value.trim();
    const age = parseInt(document.getElementById("pass-age").value);
    const gender = document.getElementById("pass-gender").value;
    const idDoc = document.getElementById("pass-doc").value.trim();
    const email = document.getElementById("pass-email").value.trim();
    const phone = document.getElementById("pass-phone").value.trim();
    const isPriority = document.getElementById("pass-priority").checked;

    const payload = {
        flightId: selectedFlight.flightId,
        travelDate: travelDate,
        travelClass: travelClass,
        contactName: fullName,
        contactEmail: email,
        contactPhone: phone,
        fullName: fullName,
        age: age,
        gender: gender,
        idPassportNumber: idDoc,
        seatNumber: selectedSeatNumber,
        mealId: selectedMeal ? selectedMeal.mealId : 1,
        isPriority: isPriority
    };

    const submitBtn = document.getElementById("btn-submit-booking");
    submitBtn.disabled = true;
    submitBtn.textContent = "Securing Flight Reservation...";

    try {
        const res = await fetch(`${API_BASE}/api/book`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await res.json();
        submitBtn.disabled = false;

        if (data.success) {
            closeBookingModal();
            lastConfirmedPnr = data.pnr;
            showBookingSuccessModal(data);
            showToast(data.message, data.status === "CONFIRMED" ? "success" : "warning");
            loadNotifications();
            handleFlightSearch();
        } else {
            showToast(data.message || "Failed to complete reservation", "danger");
        }
    } catch (err) {
        submitBtn.disabled = false;
        console.error("Booking error:", err);
        showToast("Server connection error during booking", "danger");
    }
}

function showBookingSuccessModal(data) {
    const isConfirmed = data.status === "CONFIRMED";
    const modal = document.getElementById("success-modal");
    const container = document.getElementById("booking-result-card");

    const travelDate = document.getElementById("travel-date").value;
    const travelClass = document.querySelector('input[name="travelClass"]:checked').value;
    const passengerName = document.getElementById("pass-name").value;

    container.innerHTML = `
        <div class="boarding-pass">
            <div class="pass-header">
                <div>
                    <span class="pass-pnr">PNR: ${data.pnr}</span>
                    <div style="font-size:0.8rem; color:#94a3b8; margin-top:2px;">Skyline Airways Boarding Pass</div>
                </div>
                <span class="status-badge ${isConfirmed ? "confirmed" : "waiting_list"}">
                    ${isConfirmed ? "CONFIRMED" : `WAITING LIST (WL-${data.wlPosition})`}
                </span>
            </div>

            <div class="pass-body">
                <div class="pass-grid">
                    <div class="pass-field">
                        <label>Passenger</label>
                        <span>${passengerName}</span>
                    </div>
                    <div class="pass-field">
                        <label>Flight</label>
                        <span>${selectedFlight.airlineName} (${selectedFlight.flightNumber})</span>
                    </div>
                    <div class="pass-field">
                        <label>Class</label>
                        <span>${travelClass}</span>
                    </div>
                    <div class="pass-field">
                        <label>Route</label>
                        <span>${selectedFlight.originAirport} → ${selectedFlight.destinationAirport}</span>
                    </div>
                    <div class="pass-field">
                        <label>Date & Time</label>
                        <span>${travelDate} @ ${selectedFlight.departureTime.substring(0, 5)}</span>
                    </div>
                    <div class="pass-field">
                        <label>Assigned Seat</label>
                        <span style="color:var(--primary); font-weight:700;">${data.seatNumber || (isConfirmed ? "Auto-assigned" : "Unassigned (Waitlist)")}</span>
                    </div>
                    <div class="pass-field">
                        <label>In-Flight Dining</label>
                        <span>${selectedMeal ? selectedMeal.mealName : "Complimentary Water"}</span>
                    </div>
                    <div class="pass-field">
                        <label>Total Fare (INR)</label>
                        <span>${formatINR(data.totalAmount)}</span>
                    </div>
                    <div class="pass-field">
                        <label>DSA Queue Status</label>
                        <span>${isConfirmed ? "Active Confirmed" : `FIFO/Heap WL-${data.wlPosition}`}</span>
                    </div>
                </div>

                <div style="font-size:0.85rem; color:#475569; background:#f8fafc; padding:0.8rem; border-radius:6px;">
                    ${isConfirmed ?
                        `✔ Your e-ticket and confirmation notice have been generated. Please arrive at ${selectedFlight.originAirport} at least 2 hours prior to departure.` :
                        `⏳ Flight capacity is reached. You are securely placed in our <strong>DSA Waiting List Queue</strong> at position WL-${data.wlPosition}. When any passenger cancels, your ticket will be automatically promoted to Confirmed!`
                    }
                </div>

                <div class="pass-barcode"></div>
            </div>
        </div>
    `;

    modal.classList.add("active");
}

function closeSuccessModal() {
    document.getElementById("success-modal").classList.remove("active");
}

function viewPnrDetails() {
    closeSuccessModal();
    if (lastConfirmedPnr) {
        document.getElementById("history-query").value = lastConfirmedPnr;
        switchTab("history-section");
        searchBookingsHistory();
    }
}

// =========================================================================
// 7. BOOKING HISTORY & CANCELLATION (WITH AUTO-PROMOTION)
// =========================================================================
async function searchBookingsHistory() {
    const query = document.getElementById("history-query").value.trim();
    if (!query) {
        showToast("Please enter a PNR or Mobile/Email to search", "warning");
        return;
    }

    const container = document.getElementById("history-results");
    container.innerHTML = `<div class="empty-state"><p>Searching booking records...</p></div>`;

    try {
        const res = await fetch(`${API_BASE}/api/history?query=${encodeURIComponent(query)}`);
        const bookings = await res.json();

        if (!bookings || bookings.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <p>No booking found matching "${query}". Check your PNR code (e.g. SKY-77821) and try again.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = bookings.map(b => {
            const isConfirmed = b.status === "CONFIRMED";
            const isCancelled = b.status === "CANCELLED";
            const isWL = b.status === "WAITING_LIST";

            let statusClass = "confirmed";
            let statusText = "CONFIRMED";
            if (isCancelled) {
                statusClass = "cancelled";
                statusText = "CANCELLED";
            } else if (isWL) {
                statusClass = "waiting_list";
                statusText = `WAITING LIST (WL-${b.wlPosition || 1})`;
            }

            const passenger = (b.passengers && b.passengers.length > 0) ? b.passengers[0] : null;
            const passengerName = passenger ? passenger.fullName : b.contactName;
            const seatNumber = passenger ? (passenger.seatNumber || "None") : "None";
            const mealName = passenger ? (passenger.mealName || "None") : "None";

            return `
                <div class="history-card">
                    <div style="flex:1; min-width:280px;">
                        <div style="display:flex; align-items:center; gap:0.8rem; margin-bottom:0.4rem;">
                            <span style="font-family:'JetBrains Mono', monospace; font-weight:800; font-size:1.1rem; color:var(--primary);">${b.pnr}</span>
                            <span class="status-badge ${statusClass}">${statusText}</span>
                        </div>
                        <div style="font-size:0.95rem; font-weight:700; color:#0f172a;">
                            ${b.flight ? `${b.flight.airlineName} (${b.flight.flightNumber})` : `Flight #${b.flightId}`}
                            - ${b.flight ? `${b.flight.originCity} → ${b.flight.destinationCity}` : ""}
                        </div>
                        <div style="font-size:0.85rem; color:var(--text-muted); margin-top:0.2rem;">
                            Travel Date: <strong>${b.travelDate}</strong> | Class: <strong>${b.travelClass}</strong> | Passenger: <strong>${passengerName}</strong>
                        </div>
                        <div style="font-size:0.82rem; color:#475569; margin-top:0.2rem;">
                            Seat: <strong>${seatNumber}</strong> | Dining: <strong>${mealName}</strong> | Total: <strong>${formatINR(b.totalAmount)}</strong>
                        </div>
                    </div>

                    <div>
                        ${!isCancelled ? `
                            <button class="btn btn-sm btn-danger" onclick="cancelBooking('${b.pnr}')">
                                Cancel Ticket
                            </button>
                        ` : `
                            <span style="font-size:0.85rem; color:var(--danger); font-weight:700;">Refund Processed</span>
                        `}
                    </div>
                </div>
            `;
        }).join("");
    } catch (err) {
        console.error("History search error:", err);
        container.innerHTML = `<div class="empty-state"><p style="color:var(--danger)">Error fetching booking history.</p></div>`;
    }
}

function loadSamplePnr() {
    document.getElementById("history-query").value = "SKY-77821";
    searchBookingsHistory();
}

async function cancelBooking(pnr) {
    if (!confirm(`Are you sure you want to cancel booking ${pnr}? A 90% refund in INR will be processed and any waiting list passengers will be promoted automatically.`)) {
        return;
    }

    try {
        const res = await fetch(`${API_BASE}/api/cancel`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ pnr: pnr })
        });

        const data = await res.json();
        if (data.success) {
            showToast(data.message, "danger");
            if (data.promotedPnr) {
                setTimeout(() => {
                    showToast(`⭐ WAITING LIST PROMOTION: Passenger ${data.promotedPnr} has been automatically CONFIRMED!`, "success");
                }, 1500);
            }
            searchBookingsHistory();
            loadNotifications();
            handleFlightSearch();
        } else {
            showToast(data.message || "Cancellation failed", "danger");
        }
    } catch (err) {
        console.error("Cancellation error:", err);
        showToast("Error connecting to server for cancellation", "danger");
    }
}

// =========================================================================
// 8. NOTIFICATIONS SYSTEM
// =========================================================================
async function loadNotifications() {
    try {
        const res = await fetch(`${API_BASE}/api/notifications?limit=15`);
        const notifs = await res.json();

        const badge = document.getElementById("notif-badge");
        badge.textContent = notifs.length;

        const list = document.getElementById("notif-list");
        if (!notifs || notifs.length === 0) {
            list.innerHTML = `<div class="empty-state"><p>No notifications yet.</p></div>`;
            return;
        }

        list.innerHTML = notifs.map(n => `
            <div class="notif-item ${n.eventType}">
                <h5>${n.subject}</h5>
                <p>${n.message}</p>
                <small style="color:#94a3b8; font-size:0.72rem; display:block; margin-top:0.3rem;">${n.createdAt || "Just now"}</small>
            </div>
        `).join("");
    } catch (err) {
        console.error("Notifications fetch error:", err);
    }
}

function showToast(message, type = "info") {
    const container = document.getElementById("toast-container");
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = "0";
        setTimeout(() => toast.remove(), 300);
    }, 4500);
}

// =========================================================================
// 9. DSA BINARY SEARCH INTERACTIVE TESTER (INR)
// =========================================================================
async function testBinarySearchBudget() {
    const budget = document.getElementById("test-budget").value;
    const box = document.getElementById("binary-search-results");
    box.innerHTML = "Executing Binary Search O(log N)...";

    try {
        const res = await fetch(`${API_BASE}/api/flights/binary-search?budget=${budget}`);
        const data = await res.json();

        if (data.flights) {
            const flightList = data.flights.map(f => `${f.flightNumber} (${f.originAirport}→${f.destinationAirport}) - ${formatINR(f.economyFare)}`).join(", ");
            box.innerHTML = `
                <strong>Algorithm:</strong> ${data.algorithm}<br>
                <strong>Max Budget:</strong> ${formatINR(data.maxBudget)}<br>
                <strong>Found Flights (${data.matchesCount}):</strong> ${flightList || "None in this fare range"}
            `;
        } else {
            box.textContent = JSON.stringify(data);
        }
    } catch (err) {
        box.textContent = "Error executing Binary Search.";
    }
}