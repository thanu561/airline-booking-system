package com.airline.model;

public class Passenger {
    private int passengerId;
    private String pnr;
    private String fullName;
    private int age;
    private String gender;
    private String idPassportNumber;
    private String seatNumber;
    private Integer mealId;
    private String mealName;
    private double mealPrice;
    private boolean isPriority;
    private int priorityScore;

    public Passenger() {}

    public Passenger(int passengerId, String pnr, String fullName, int age, String gender,
                     String idPassportNumber, String seatNumber, Integer mealId, boolean isPriority, int priorityScore) {
        this.passengerId = passengerId;
        this.pnr = pnr;
        this.fullName = fullName;
        this.age = age;
        this.gender = gender;
        this.idPassportNumber = idPassportNumber;
        this.seatNumber = seatNumber;
        this.mealId = mealId;
        this.isPriority = isPriority;
        this.priorityScore = priorityScore;
    }

    public int getPassengerId() { return passengerId; }
    public void setPassengerId(int passengerId) { this.passengerId = passengerId; }

    public String getPnr() { return pnr; }
    public void setPnr(String pnr) { this.pnr = pnr; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getIdPassportNumber() { return idPassportNumber; }
    public void setIdPassportNumber(String idPassportNumber) { this.idPassportNumber = idPassportNumber; }

    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }

    public Integer getMealId() { return mealId; }
    public void setMealId(Integer mealId) { this.mealId = mealId; }

    public String getMealName() { return mealName; }
    public void setMealName(String mealName) { this.mealName = mealName; }

    public double getMealPrice() { return mealPrice; }
    public void setMealPrice(double mealPrice) { this.mealPrice = mealPrice; }

    public boolean isPriority() { return isPriority; }
    public void setPriority(boolean priority) { isPriority = priority; }

    public int getPriorityScore() { return priorityScore; }
    public void setPriorityScore(int priorityScore) { this.priorityScore = priorityScore; }
}