package com.airline.dao;

import com.airline.config.DbConfig;
import com.airline.model.Booking;
import com.airline.model.Passenger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BookingDao {
    private final FlightDao flightDao = new FlightDao();
    private final MealDao mealDao = new MealDao();

    // In-memory cache fallback if DB is not reachable
    private static final Map<String, Booking> memoryBookings = new ConcurrentHashMap<>();

    public boolean saveBooking(Booking booking) {
        memoryBookings.put(booking.getPnr(), booking);
        String sql = "INSERT INTO bookings (pnr, flight_id, travel_date, travel_class, contact_name, contact_email, contact_phone, total_amount, status, wl_position) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, booking.getPnr());
            ps.setInt(2, booking.getFlightId());
            ps.setString(3, booking.getTravelDate());
            ps.setString(4, booking.getTravelClass());
            ps.setString(5, booking.getContactName());
            ps.setString(6, booking.getContactEmail());
            ps.setString(7, booking.getContactPhone());
            ps.setDouble(8, booking.getTotalAmount());
            ps.setString(9, booking.getStatus());
            if (booking.getWlPosition() != null) {
                ps.setInt(10, booking.getWlPosition());
            } else {
                ps.setNull(10, java.sql.Types.INTEGER);
            }
            int affected = ps.executeUpdate();
            if (affected > 0) {
                savePassengers(booking.getPassengers(), booking.getPnr());
                return true;
            }
        } catch (Exception e) {
            System.err.println("[BookingDao] DB saveBooking note: " + e.getMessage() + ". Saved to memory cache.");
        }
        return true;
    }

    public void savePassengers(List<Passenger> passengers, String pnr) {
        if (passengers == null || passengers.isEmpty()) return;
        String sql = "INSERT INTO passengers (pnr, full_name, age, gender, id_passport_number, seat_number, meal_id, is_priority, priority_score) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (Passenger p : passengers) {
                ps.setString(1, pnr);
                ps.setString(2, p.getFullName());
                ps.setInt(3, p.getAge());
                ps.setString(4, p.getGender());
                ps.setString(5, p.getIdPassportNumber());
                ps.setString(6, p.getSeatNumber());
                if (p.getMealId() != null) {
                    ps.setInt(7, p.getMealId());
                } else {
                    ps.setNull(7, java.sql.Types.INTEGER);
                }
                ps.setBoolean(8, p.isPriority());
                ps.setInt(9, p.getPriorityScore());
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (Exception e) {
            System.err.println("[BookingDao] DB savePassengers note: " + e.getMessage());
        }
    }

    public Booking getBookingByPnr(String pnr) {
        String sql = "SELECT * FROM bookings WHERE pnr = ?";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, pnr);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Booking b = mapResultSetToBooking(rs);
                    b.setFlight(flightDao.getFlightById(b.getFlightId()));
                    b.setPassengers(getPassengersByPnr(pnr));
                    return b;
                }
            }
        } catch (Exception e) {
            System.err.println("[BookingDao] Error getBookingByPnr: " + e.getMessage());
        }
        Booking mem = memoryBookings.get(pnr);
        if (mem != null) {
            if (mem.getFlight() == null) mem.setFlight(flightDao.getFlightById(mem.getFlightId()));
            return mem;
        }
        return null;
    }

    public List<Booking> searchBookings(String query) {
        List<Booking> list = new ArrayList<>();
        String sql = "SELECT * FROM bookings WHERE pnr = ? OR contact_email LIKE ? OR contact_phone LIKE ? ORDER BY booking_id DESC";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, query.trim());
            ps.setString(2, "%" + query.trim() + "%");
            ps.setString(3, "%" + query.trim() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Booking b = mapResultSetToBooking(rs);
                    b.setFlight(flightDao.getFlightById(b.getFlightId()));
                    b.setPassengers(getPassengersByPnr(b.getPnr()));
                    list.add(b);
                }
            }
        } catch (Exception e) {
            System.err.println("[BookingDao] Error searchBookings: " + e.getMessage());
        }

        if (list.isEmpty()) {
            for (Booking b : memoryBookings.values()) {
                if (b.getPnr().equalsIgnoreCase(query) ||
                        (b.getContactEmail() != null && b.getContactEmail().toLowerCase().contains(query.toLowerCase())) ||
                        (b.getContactPhone() != null && b.getContactPhone().contains(query))) {
                    if (b.getFlight() == null) b.setFlight(flightDao.getFlightById(b.getFlightId()));
                    list.add(b);
                }
            }
        }
        return list;
    }

    public List<Passenger> getPassengersByPnr(String pnr) {
        List<Passenger> list = new ArrayList<>();
        String sql = "SELECT p.*, m.meal_name, m.price as meal_price FROM passengers p " +
                "LEFT JOIN meals m ON p.meal_id = m.meal_id WHERE p.pnr = ?";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, pnr);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Passenger p = new Passenger(
                            rs.getInt("passenger_id"),
                            rs.getString("pnr"),
                            rs.getString("full_name"),
                            rs.getInt("age"),
                            rs.getString("gender"),
                            rs.getString("id_passport_number"),
                            rs.getString("seat_number"),
                            (Integer) rs.getObject("meal_id"),
                            rs.getBoolean("is_priority"),
                            rs.getInt("priority_score")
                    );
                    p.setMealName(rs.getString("meal_name"));
                    p.setMealPrice(rs.getDouble("meal_price"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
            System.err.println("[BookingDao] Error getPassengersByPnr: " + e.getMessage());
        }
        return list;
    }

    public boolean updateStatus(String pnr, String status, Integer wlPosition) {
        Booking mem = memoryBookings.get(pnr);
        if (mem != null) {
            mem.setStatus(status);
            mem.setWlPosition(wlPosition);
        }

        String sql = "UPDATE bookings SET status = ?, wl_position = ? WHERE pnr = ?";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            if (wlPosition != null) {
                ps.setInt(2, wlPosition);
            } else {
                ps.setNull(2, java.sql.Types.INTEGER);
            }
            ps.setString(3, pnr);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("[BookingDao] Error updateStatus: " + e.getMessage());
            return true;
        }
    }

    public List<Booking> getWaitingListByFlight(int flightId) {
        List<Booking> list = new ArrayList<>();
        String sql = "SELECT * FROM bookings WHERE flight_id = ? AND status = 'WAITING_LIST' ORDER BY wl_position ASC, booking_id ASC";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Booking b = mapResultSetToBooking(rs);
                    b.setFlight(flightDao.getFlightById(flightId));
                    b.setPassengers(getPassengersByPnr(b.getPnr()));
                    list.add(b);
                }
            }
        } catch (Exception e) {
            System.err.println("[BookingDao] Error getWaitingListByFlight: " + e.getMessage());
        }

        if (list.isEmpty()) {
            for (Booking b : memoryBookings.values()) {
                if (b.getFlightId() == flightId && "WAITING_LIST".equalsIgnoreCase(b.getStatus())) {
                    list.add(b);
                }
            }
        }
        return list;
    }

    private Booking mapResultSetToBooking(ResultSet rs) throws Exception {
        return new Booking(
                rs.getInt("booking_id"),
                rs.getString("pnr"),
                rs.getInt("flight_id"),
                rs.getString("travel_date"),
                rs.getString("travel_class"),
                rs.getString("contact_name"),
                rs.getString("contact_email"),
                rs.getString("contact_phone"),
                rs.getDouble("total_amount"),
                rs.getString("status"),
                (Integer) rs.getObject("wl_position"),
                rs.getString("created_at")
        );
    }
}