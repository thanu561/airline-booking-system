package com.airline.service;

import com.airline.dao.BookingDao;
import com.airline.dao.FlightDao;
import com.airline.dao.MealDao;
import com.airline.dao.SeatDao;
import com.airline.dsa.PriorityWaitingList;
import com.airline.dsa.WaitingListQueue;
import com.airline.model.Booking;
import com.airline.model.Flight;
import com.airline.model.Meal;
import com.airline.model.Passenger;
import com.airline.model.Seat;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BookingService {
    private final BookingDao bookingDao = new BookingDao();
    private final FlightDao flightDao = new FlightDao();
    private final SeatDao seatDao = new SeatDao();
    private final MealDao mealDao = new MealDao();
    private final NotificationService notificationService = new NotificationService();

    private static final Map<Integer, WaitingListQueue> flightWaitingQueues = new ConcurrentHashMap<>();
    private static final Map<Integer, PriorityWaitingList> flightPriorityQueues = new ConcurrentHashMap<>();

    private static final SecureRandom random = new SecureRandom();
    private static final String CHARS = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";

    public BookingService() {
        preloadWaitingQueues();
    }

    private void preloadWaitingQueues() {
        try {
            for (Flight f : flightDao.getAllFlights()) {
                List<Booking> wlList = bookingDao.getWaitingListByFlight(f.getFlightId());
                if (!wlList.isEmpty()) {
                    WaitingListQueue queue = getWaitingQueue(f.getFlightId());
                    PriorityWaitingList pQueue = getPriorityQueue(f.getFlightId());
                    for (Booking b : wlList) {
                        queue.enqueue(b);
                        pQueue.insert(b);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[BookingService] Notice preloading WL queues: " + e.getMessage());
        }
    }

    public synchronized WaitingListQueue getWaitingQueue(int flightId) {
        return flightWaitingQueues.computeIfAbsent(flightId, k -> new WaitingListQueue());
    }

    public synchronized PriorityWaitingList getPriorityQueue(int flightId) {
        return flightPriorityQueues.computeIfAbsent(flightId, k -> new PriorityWaitingList());
    }

    public synchronized Map<String, Object> processBooking(Booking booking, List<Passenger> passengers, boolean usePriorityQueue) {
        Map<String, Object> response = new HashMap<>();

        Flight flight = flightDao.getFlightById(booking.getFlightId());
        if (flight == null) {
            response.put("success", false);
            response.put("message", "Flight not found for ID " + booking.getFlightId());
            return response;
        }
        booking.setFlight(flight);

        String pnr = generatePnr();
        booking.setPnr(pnr);

        boolean isBusiness = "BUSINESS".equalsIgnoreCase(booking.getTravelClass());
        double baseFare = isBusiness ? flight.getBusinessFare() : flight.getEconomyFare();
        double totalMealPrice = 0.0;

        String assignedSeatNumber = null;
        String mealNames = "";

        if (passengers != null && !passengers.isEmpty()) {
            for (Passenger p : passengers) {
                p.setPnr(pnr);
                int pScore = 0;
                if (isBusiness) pScore += 50;
                else pScore += 10;
                if (p.getAge() >= 60) {
                    pScore += 40;
                    p.setPriority(true);
                } else if (p.getAge() <= 5) {
                    pScore += 20;
                    p.setPriority(true);
                }
                if (p.isPriority()) pScore += 30;
                p.setPriorityScore(pScore);

                if (p.getMealId() != null && p.getMealId() > 0) {
                    Meal m = mealDao.getMealById(p.getMealId());
                    if (m != null) {
                        totalMealPrice += m.getPrice();
                        p.setMealName(m.getMealName());
                        p.setMealPrice(m.getPrice());
                        mealNames += m.getMealName() + "; ";
                    }
                }

                if (assignedSeatNumber == null && p.getSeatNumber() != null) {
                    assignedSeatNumber = p.getSeatNumber();
                }
            }
        }

        int passengerCount = (passengers != null && !passengers.isEmpty()) ? passengers.size() : 1;
        double grandTotal = (baseFare * passengerCount) + totalMealPrice;
        booking.setTotalAmount(grandTotal);
        booking.setPassengers(passengers != null ? passengers : new ArrayList<>());

        if (flight.getAvailableSeats() >= passengerCount) {
            booking.setStatus("CONFIRMED");
            booking.setWlPosition(null);

            List<Seat> flightSeats = seatDao.getSeatsByFlightId(flight.getFlightId());
            for (Passenger p : booking.getPassengers()) {
                String seatToBook = p.getSeatNumber();
                if (seatToBook == null || seatToBook.isEmpty()) {
                    for (Seat s : flightSeats) {
                        if (!s.isBooked() && s.getSeatClass().equalsIgnoreCase(booking.getTravelClass())) {
                            seatToBook = s.getSeatNumber();
                            s.setBooked(true);
                            p.setSeatNumber(seatToBook);
                            break;
                        }
                    }
                }
                if (seatToBook != null) {
                    seatDao.bookSeat(flight.getFlightId(), seatToBook, pnr);
                    if (assignedSeatNumber == null) assignedSeatNumber = seatToBook;
                }
            }

            flightDao.updateAvailableSeats(flight.getFlightId(), -passengerCount);
            bookingDao.saveBooking(booking);

            notificationService.notifyBookingConfirmed(booking, assignedSeatNumber, mealNames);

            int remaining = flight.getAvailableSeats() - passengerCount;
            if (remaining > 0 && remaining <= 3) {
                notificationService.notifyLowSeatAvailability(flight, remaining);
            }

            response.put("success", true);
            response.put("status", "CONFIRMED");
            response.put("pnr", pnr);
            response.put("totalAmount", grandTotal);
            response.put("seatNumber", assignedSeatNumber);
            response.put("message", "Booking Confirmed successfully! PNR: " + pnr);
        } else {
            booking.setStatus("WAITING_LIST");

            WaitingListQueue queue = getWaitingQueue(flight.getFlightId());
            PriorityWaitingList pQueue = getPriorityQueue(flight.getFlightId());

            queue.enqueue(booking);
            pQueue.insert(booking);
            int wlPos = queue.size();
            booking.setWlPosition(wlPos);

            bookingDao.saveBooking(booking);

            notificationService.notifyWaitingListAssigned(booking, wlPos);

            response.put("success", true);
            response.put("status", "WAITING_LIST");
            response.put("pnr", pnr);
            response.put("wlPosition", wlPos);
            response.put("totalAmount", grandTotal);
            response.put("message", "Flight capacity is full. Added to Waiting List at position WL-" + wlPos);
        }

        response.put("booking", booking);
        return response;
    }

    public synchronized Map<String, Object> cancelBooking(String pnr) {
        Map<String, Object> response = new HashMap<>();
        Booking booking = bookingDao.getBookingByPnr(pnr);

        if (booking == null) {
            response.put("success", false);
            response.put("message", "Booking not found with PNR: " + pnr);
            return response;
        }

        if ("CANCELLED".equalsIgnoreCase(booking.getStatus())) {
            response.put("success", false);
            response.put("message", "Booking with PNR " + pnr + " is already cancelled.");
            return response;
        }

        boolean wasConfirmed = "CONFIRMED".equalsIgnoreCase(booking.getStatus());
        int flightId = booking.getFlightId();

        bookingDao.updateStatus(pnr, "CANCELLED", null);
        booking.setStatus("CANCELLED");

        double refundAmount = booking.getTotalAmount() * 0.90;
        notificationService.notifyBookingCancelled(booking, refundAmount);

        String promotedPnr = null;

        if (wasConfirmed) {
            String releasedSeat = null;
            if (booking.getPassengers() != null && !booking.getPassengers().isEmpty()) {
                releasedSeat = booking.getPassengers().get(0).getSeatNumber();
            }
            if (releasedSeat == null) releasedSeat = "3A";

            seatDao.releaseSeat(flightId, releasedSeat);

            WaitingListQueue queue = getWaitingQueue(flightId);
            PriorityWaitingList pQueue = getPriorityQueue(flightId);

            Booking nextToPromote = null;
            if (!pQueue.isEmpty()) {
                nextToPromote = pQueue.extractMax();
                if (nextToPromote != null) {
                    queue.removeByPnr(nextToPromote.getPnr());
                }
            } else if (!queue.isEmpty()) {
                nextToPromote = queue.dequeue();
            }

            if (nextToPromote != null) {
                nextToPromote.setStatus("CONFIRMED");
                nextToPromote.setWlPosition(null);
                promotedPnr = nextToPromote.getPnr();

                seatDao.bookSeat(flightId, releasedSeat, promotedPnr);
                if (nextToPromote.getPassengers() != null && !nextToPromote.getPassengers().isEmpty()) {
                    nextToPromote.getPassengers().get(0).setSeatNumber(releasedSeat);
                }
                bookingDao.updateStatus(promotedPnr, "CONFIRMED", null);

                notificationService.notifyWaitingListPromoted(nextToPromote, releasedSeat);
            } else {
                flightDao.updateAvailableSeats(flightId, 1);
            }
        } else if ("WAITING_LIST".equalsIgnoreCase(booking.getStatus())) {
            WaitingListQueue queue = getWaitingQueue(flightId);
            PriorityWaitingList pQueue = getPriorityQueue(flightId);
            queue.removeByPnr(pnr);
            pQueue.removeByPnr(pnr);
        }

        response.put("success", true);
        response.put("pnr", pnr);
        response.put("refundAmount", refundAmount);
        response.put("message", "Booking cancelled successfully. Refund of ₹" + String.format("%,.2f", refundAmount) + " processed.");
        if (promotedPnr != null) {
            response.put("promotedPnr", promotedPnr);
            response.put("promotionMessage", "Waiting list passenger (PNR: " + promotedPnr + ") was automatically promoted to CONFIRMED!");
        }
        return response;
    }

    public Booking getBooking(String pnr) {
        return bookingDao.getBookingByPnr(pnr);
    }

    public List<Booking> searchHistory(String query) {
        return bookingDao.searchBookings(query);
    }

    public Map<String, Object> getDsaInspectionMetrics() {
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("activeWaitingQueuesCount", flightWaitingQueues.size());
        metrics.put("activePriorityQueuesCount", flightPriorityQueues.size());

        List<Map<String, Object>> flightQueuesDetail = new ArrayList<>();
        for (Map.Entry<Integer, WaitingListQueue> entry : flightWaitingQueues.entrySet()) {
            if (entry.getValue().size() > 0) {
                Map<String, Object> item = new HashMap<>();
                item.put("flightId", entry.getKey());
                item.put("queueSize", entry.getValue().size());
                PriorityWaitingList pq = flightPriorityQueues.get(entry.getKey());
                item.put("priorityHeapSize", pq != null ? pq.size() : 0);
                flightQueuesDetail.add(item);
            }
        }
        metrics.put("flightQueues", flightQueuesDetail);
        return metrics;
    }

    private String generatePnr() {
        StringBuilder sb = new StringBuilder("SKY-");
        for (int i = 0; i < 5; i++) {
            sb.append(CHARS.charAt(random.nextInt(CHARS.length())));
        }
        return sb.toString();
    }
}