package com.airline;

import com.airline.dsa.*;
import com.airline.model.Booking;
import com.airline.model.Flight;
import com.airline.model.Passenger;
import java.util.ArrayList;
import java.util.List;

public class DsaTestSuite {
    public static void main(String[] args) {
        System.out.println("Running DSA Verification Test Suite...");

        // 1. Test FlightArray & SeatMatrix (Array DSA)
        FlightArray flightArray = new FlightArray();
        Flight f1 = new Flight(1, "FL-001", "Air-A", "DOMESTIC", "NYC", "JFK", "LAX", "LAX", "08:00", "11:00", 180, 250.0, 500.0, 30, 30);
        Flight f2 = new Flight(2, "FL-002", "Air-B", "INTERNATIONAL", "NYC", "JFK", "LHR", "LHR", "19:00", "07:00", 420, 700.0, 1500.0, 30, 30);
        Flight f3 = new Flight(3, "FL-003", "Air-C", "DOMESTIC", "CHI", "ORD", "MIA", "MIA", "10:00", "14:00", 240, 180.0, 350.0, 30, 30);
        flightArray.add(f1);
        flightArray.add(f2);
        flightArray.add(f3);
        assertCondition(flightArray.size() == 3, "FlightArray size should be 3");

        FlightArray.SeatMatrix seatMatrix = new FlightArray.SeatMatrix();
        seatMatrix.initializeSeats(1);
        boolean booked = seatMatrix.bookSeat("3A", "SKY-TEST1");
        assertCondition(booked, "Seat 3A should be successfully booked");
        assertCondition(seatMatrix.getSeatByNumber("3A").isBooked(), "Seat 3A isBooked should be true");
        boolean released = seatMatrix.releaseSeat("3A");
        assertCondition(released, "Seat 3A should be successfully released");
        assertCondition(!seatMatrix.getSeatByNumber("3A").isBooked(), "Seat 3A isBooked should be false");

        // 2. Test Merge Sort by Fare (Sorting DSA)
        Flight[] toSortFares = flightArray.toArray();
        FlightSorter.mergeSortByFare(toSortFares, true, false);
        assertCondition(toSortFares[0].getEconomyFare() == 180.0, "Lowest fare should be 180.0");
        assertCondition(toSortFares[2].getEconomyFare() == 700.0, "Highest fare should be 700.0");

        // 3. Test Quick Sort by Duration (Sorting DSA)
        Flight[] toSortDuration = flightArray.toArray();
        FlightSorter.quickSortByDuration(toSortDuration, true);
        assertCondition(toSortDuration[0].getDurationMinutes() == 180, "Shortest duration should be 180 mins");
        assertCondition(toSortDuration[2].getDurationMinutes() == 420, "Longest duration should be 420 mins");

        // 4. Test Binary Search (Searching DSA)
        Flight found = FlightSearchEngine.binarySearchById(flightArray.toArray(), 2);
        assertCondition(found != null && found.getFlightNumber().equals("FL-002"), "Binary search should find FL-002");

        List<Flight> budgetFlights = FlightSearchEngine.binarySearchByMaxFare(toSortFares, 260.0);
        assertCondition(budgetFlights.size() == 2, "Binary search max fare <= 260 should find 2 flights");

        // 5. Test WaitingListQueue (FIFO Queue DSA)
        WaitingListQueue wlQueue = new WaitingListQueue();
        Booking b1 = new Booking(1, "SKY-B1", 1, "2026-09-10", "ECONOMY", "User1", "u1@test.com", "111", 200.0, "WAITING_LIST", null, null);
        Booking b2 = new Booking(2, "SKY-B2", 1, "2026-09-10", "ECONOMY", "User2", "u2@test.com", "222", 200.0, "WAITING_LIST", null, null);
        wlQueue.enqueue(b1);
        wlQueue.enqueue(b2);
        assertCondition(b1.getWlPosition() == 1, "b1 position should be WL-1");
        assertCondition(b2.getWlPosition() == 2, "b2 position should be WL-2");
        Booking dequeued = wlQueue.dequeue();
        assertCondition(dequeued.getPnr().equals("SKY-B1"), "FIFO Queue should dequeue SKY-B1 first");
        assertCondition(b2.getWlPosition() == 1, "b2 should be re-indexed to WL-1");

        // 6. Test PriorityWaitingList (Max-Heap Priority Queue DSA)
        PriorityWaitingList pQueue = new PriorityWaitingList();
        Booking regularBooking = new Booking(3, "SKY-REG", 1, "2026-09-10", "ECONOMY", "Regular", "reg@test.com", "333", 200.0, "WAITING_LIST", null, null);
        List<Passenger> regPList = new ArrayList<>();
        regPList.add(new Passenger(1, "SKY-REG", "Regular Traveler", 30, "Male", "P1", "3B", null, false, 0));
        regularBooking.setPassengers(regPList);

        Booking seniorBooking = new Booking(4, "SKY-SENIOR", 1, "2026-09-10", "ECONOMY", "Senior", "sen@test.com", "444", 200.0, "WAITING_LIST", null, null);
        List<Passenger> senPList = new ArrayList<>();
        senPList.add(new Passenger(2, "SKY-SENIOR", "Senior Traveler", 72, "Female", "P2", "3C", null, true, 0));
        seniorBooking.setPassengers(senPList);

        pQueue.insert(regularBooking);
        pQueue.insert(seniorBooking);

        Booking highestPriority = pQueue.extractMax();
        assertCondition(highestPriority.getPnr().equals("SKY-SENIOR"), "Priority Queue should extract Senior Citizen before regular booking!");

        System.out.println("ALL DSA UNIT TESTS PASSED SUCCESSFULLY! (6/6 Suites)");
    }

    private static void assertCondition(boolean condition, String testDesc) {
        if (!condition) {
            throw new AssertionError("TEST FAILED: " + testDesc);
        }
        System.out.println("  [PASS] " + testDesc);
    }
}