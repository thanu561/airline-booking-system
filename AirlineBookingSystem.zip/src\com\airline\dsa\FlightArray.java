package com.airline.dsa;

import com.airline.model.Flight;
import com.airline.model.Seat;
import java.util.Arrays;

/**
 * DSA CONCEPT: ARRAY & 2D MATRIX
 * 1. FlightArray: Custom dynamic resizable array for storing and accessing flight records.
 * 2. SeatMatrix: 2D Matrix representing the aircraft cabin layout (Rows x Columns)
 *    allowing O(1) seat state lookup, seat allocation, and seat release.
 */
public class FlightArray {
    private Flight[] data;
    private int size;
    private static final int INITIAL_CAPACITY = 16;

    public FlightArray() {
        this.data = new Flight[INITIAL_CAPACITY];
        this.size = 0;
    }

    public FlightArray(int initialCapacity) {
        this.data = new Flight[initialCapacity > 0 ? initialCapacity : INITIAL_CAPACITY];
        this.size = 0;
    }

    public void add(Flight flight) {
        ensureCapacity();
        data[size++] = flight;
    }

    public Flight get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        return data[index];
    }

    public void set(int index, Flight flight) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        data[index] = flight;
    }

    public Flight remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        Flight removed = data[index];
        int numMoved = size - index - 1;
        if (numMoved > 0) {
            System.arraycopy(data, index + 1, data, index, numMoved);
        }
        data[--size] = null;
        return removed;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public Flight[] toArray() {
        return Arrays.copyOf(data, size);
    }

    public void clear() {
        Arrays.fill(data, 0, size, null);
        size = 0;
    }

    private void ensureCapacity() {
        if (size >= data.length) {
            data = Arrays.copyOf(data, data.length * 2);
        }
    }

    // =========================================================================
    // 2D SEAT MATRIX IMPLEMENTATION
    // Aircraft cabin layout: 8 Rows x 4 Columns (A, B, C, D)
    // Rows 1-2: Business, Rows 3-8: Economy
    // =========================================================================
    public static class SeatMatrix {
        public static final int ROWS = 8;
        public static final int COLS = 4; // A, B, C, D
        private final Seat[][] matrix;

        public SeatMatrix() {
            this.matrix = new Seat[ROWS][COLS];
        }

        public void initializeSeats(int flightId) {
            char[] colLabels = {'A', 'B', 'C', 'D'};
            for (int r = 0; r < ROWS; r++) {
                int rowNumber = r + 1;
                String seatClass = (rowNumber <= 2) ? "BUSINESS" : "ECONOMY";
                for (int c = 0; c < COLS; c++) {
                    if (rowNumber == 8 && (c == 2 || c == 3)) {
                        // 30 seats total: row 8 has only A & B
                        matrix[r][c] = null;
                        continue;
                    }
                    String seatNumber = rowNumber + String.valueOf(colLabels[c]);
                    matrix[r][c] = new Seat(0, flightId, seatNumber, seatClass, false, null);
                }
            }
        }

        public void setSeat(int r, int c, Seat seat) {
            if (r >= 0 && r < ROWS && c >= 0 && c < COLS) {
                matrix[r][c] = seat;
            }
        }

        public Seat getSeat(int r, int c) {
            if (r >= 0 && r < ROWS && c >= 0 && c < COLS) {
                return matrix[r][c];
            }
            return null;
        }

        public Seat getSeatByNumber(String seatNumber) {
            if (seatNumber == null || seatNumber.length() < 2) return null;
            int r = Integer.parseInt(seatNumber.substring(0, seatNumber.length() - 1)) - 1;
            char colChar = Character.toUpperCase(seatNumber.charAt(seatNumber.length() - 1));
            int c = colChar - 'A';
            return getSeat(r, c);
        }

        public boolean bookSeat(String seatNumber, String pnr) {
            Seat s = getSeatByNumber(seatNumber);
            if (s != null && !s.isBooked()) {
                s.setBooked(true);
                s.setBookedPnr(pnr);
                return true;
            }
            return false;
        }

        public boolean releaseSeat(String seatNumber) {
            Seat s = getSeatByNumber(seatNumber);
            if (s != null && s.isBooked()) {
                s.setBooked(false);
                s.setBookedPnr(null);
                return true;
            }
            return false;
        }

        public Seat[][] getMatrix() {
            return matrix;
        }
    }
}