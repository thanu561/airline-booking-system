@echo off
echo ===================================================
echo   Starting Skyline Airline Booking System Server...
echo ===================================================

if not exist "build/com/airline/Main.class" (
    echo Build directory not found. Compiling first...
    call compile.bat
)

echo Starting Java Backend & Static Web Server on port 8080...
java -cp "build;lib/mysql-connector-j-8.4.0.jar" com.airline.Main
pause