package com.airline.dsa;

import com.airline.model.Booking;
import com.airline.model.Passenger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * DSA CONCEPT: PRIORITY QUEUE (MAX-HEAP)
 * Used for High-Priority Waiting List promotion (VIPs, Senior Citizens, Business Class).
 * Uses a binary max-heap so that extractMax() executes in O(log N) time.
 */
public class PriorityWaitingList {

    public static class PrioritizedBooking implements Comparable<PrioritizedBooking> {
        private final Booking booking;
        private final int priorityScore;
        private final long sequenceNumber;

        public PrioritizedBooking(Booking booking, int priorityScore, long sequenceNumber) {
            this.booking = booking;
            this.priorityScore = priorityScore;
            this.sequenceNumber = sequenceNumber;
        }

        public Booking getBooking() { return booking; }
        public int getPriorityScore() { return priorityScore; }

        @Override
        public int compareTo(PrioritizedBooking o) {
            // Higher score has higher priority
            if (this.priorityScore != o.priorityScore) {
                return Integer.compare(this.priorityScore, o.priorityScore);
            }
            // Tie-breaker: earlier sequence number has higher priority (FIFO on tie)
            return Long.compare(o.sequenceNumber, this.sequenceNumber);
        }
    }

    private PrioritizedBooking[] heap;
    private int size;
    private long sequenceCounter;
    private static final int DEFAULT_CAPACITY = 16;

    public PriorityWaitingList() {
        this.heap = new PrioritizedBooking[DEFAULT_CAPACITY];
        this.size = 0;
        this.sequenceCounter = 0;
    }

    public static int calculatePriorityScore(Booking booking) {
        int score = 0;
        if ("BUSINESS".equalsIgnoreCase(booking.getTravelClass())) {
            score += 50;
        } else {
            score += 10;
        }

        if (booking.getPassengers() != null) {
            for (Passenger p : booking.getPassengers()) {
                if (p.isPriority()) {
                    score += 30;
                }
                if (p.getAge() >= 60) {
                    score += 40; // Senior citizen priority
                } else if (p.getAge() <= 5) {
                    score += 20; // Toddler / infant priority
                }
            }
        }
        return score;
    }

    public synchronized void insert(Booking booking) {
        if (booking == null) return;
        int score = calculatePriorityScore(booking);
        PrioritizedBooking pb = new PrioritizedBooking(booking, score, ++sequenceCounter);
        ensureCapacity();
        heap[size] = pb;
        siftUp(size);
        size++;
    }

    public synchronized Booking extractMax() {
        if (isEmpty()) return null;
        PrioritizedBooking max = heap[0];
        heap[0] = heap[size - 1];
        heap[size - 1] = null;
        size--;
        if (size > 0) {
            siftDown(0);
        }
        return max.getBooking();
    }

    public synchronized Booking peek() {
        return isEmpty() ? null : heap[0].getBooking();
    }

    public synchronized boolean isEmpty() {
        return size == 0;
    }

    public synchronized int size() {
        return size;
    }

    public synchronized boolean removeByPnr(String pnr) {
        if (pnr == null || isEmpty()) return false;
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (heap[i].getBooking().getPnr().equalsIgnoreCase(pnr)) {
                index = i;
                break;
            }
        }
        if (index == -1) return false;

        heap[index] = heap[size - 1];
        heap[size - 1] = null;
        size--;
        if (index < size) {
            siftUp(index);
            siftDown(index);
        }
        return true;
    }

    public synchronized List<PrioritizedBooking> toSortedList() {
        // Return a copy sorted by descending priority without mutating heap
        PrioritizedBooking[] copy = Arrays.copyOf(heap, size);
        Arrays.sort(copy, (a, b) -> b.compareTo(a));
        return new ArrayList<>(Arrays.asList(copy));
    }

    private void siftUp(int k) {
        while (k > 0) {
            int parent = (k - 1) / 2;
            if (heap[k].compareTo(heap[parent]) > 0) {
                swap(k, parent);
                k = parent;
            } else {
                break;
            }
        }
    }

    private void siftDown(int k) {
        int half = size / 2;
        while (k < half) {
            int left = 2 * k + 1;
            int right = left + 1;
            int best = left;

            if (right < size && heap[right].compareTo(heap[left]) > 0) {
                best = right;
            }
            if (heap[best].compareTo(heap[k]) > 0) {
                swap(k, best);
                k = best;
            } else {
                break;
            }
        }
    }

    private void swap(int i, int j) {
        PrioritizedBooking temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    private void ensureCapacity() {
        if (size >= heap.length) {
            heap = Arrays.copyOf(heap, heap.length * 2);
        }
    }
}