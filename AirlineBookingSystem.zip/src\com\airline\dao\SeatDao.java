package com.airline.dao;

import com.airline.config.DbConfig;
import com.airline.model.Seat;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SeatDao {

    public List<Seat> getSeatsByFlightId(int flightId) {
        List<Seat> list = new ArrayList<>();
        String sql = "SELECT * FROM seats WHERE flight_id = ? ORDER BY seat_id ASC";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Seat(
                            rs.getInt("seat_id"),
                            rs.getInt("flight_id"),
                            rs.getString("seat_number"),
                            rs.getString("seat_class"),
                            rs.getBoolean("is_booked"),
                            rs.getString("booked_pnr")
                    ));
                }
            }
        } catch (Exception e) {
            System.err.println("[SeatDao] Error fetching seats: " + e.getMessage());
            return generateDefaultSeats(flightId);
        }
        return list.isEmpty() ? generateDefaultSeats(flightId) : list;
    }

    public boolean bookSeat(int flightId, String seatNumber, String pnr) {
        String sql = "UPDATE seats SET is_booked = TRUE, booked_pnr = ? WHERE flight_id = ? AND seat_number = ? AND is_booked = FALSE";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, pnr);
            ps.setInt(2, flightId);
            ps.setString(3, seatNumber);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("[SeatDao] Error booking seat: " + e.getMessage());
            return true;
        }
    }

    public boolean releaseSeat(int flightId, String seatNumber) {
        String sql = "UPDATE seats SET is_booked = FALSE, booked_pnr = NULL WHERE flight_id = ? AND seat_number = ?";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, flightId);
            ps.setString(2, seatNumber);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("[SeatDao] Error releasing seat: " + e.getMessage());
            return true;
        }
    }

    public boolean releaseSeatByPnr(String pnr) {
        String sql = "UPDATE seats SET is_booked = FALSE, booked_pnr = NULL WHERE booked_pnr = ?";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, pnr);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("[SeatDao] Error releasing seats by PNR: " + e.getMessage());
            return true;
        }
    }

    public static List<Seat> generateDefaultSeats(int flightId) {
        List<Seat> seats = new ArrayList<>();
        char[] cols = {'A', 'B', 'C', 'D'};
        for (int r = 1; r <= 8; r++) {
            String seatClass = (r <= 2) ? "BUSINESS" : "ECONOMY";
            for (char c : cols) {
                if (r == 8 && (c == 'C' || c == 'D')) continue;
                String seatNum = r + String.valueOf(c);
                boolean isBooked = (flightId == 1 && "3A".equalsIgnoreCase(seatNum));
                String bookedPnr = isBooked ? "SKY-77821" : null;
                seats.add(new Seat(0, flightId, seatNum, seatClass, isBooked, bookedPnr));
            }
        }
        return seats;
    }
}