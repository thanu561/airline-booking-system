package com.airline.model;

public class Flight {
    private int flightId;
    private String flightNumber;
    private String airlineName;
    private String flightType; // DOMESTIC or INTERNATIONAL
    private String originCity;
    private String originAirport;
    private String destinationCity;
    private String destinationAirport;
    private String departureTime;
    private String arrivalTime;
    private int durationMinutes;
    private double economyFare;
    private double businessFare;
    private int totalSeats;
    private int availableSeats;

    public Flight() {}

    public Flight(int flightId, String flightNumber, String airlineName, String flightType,
                  String originCity, String originAirport, String destinationCity, String destinationAirport,
                  String departureTime, String arrivalTime, int durationMinutes,
                  double economyFare, double businessFare, int totalSeats, int availableSeats) {
        this.flightId = flightId;
        this.flightNumber = flightNumber;
        this.airlineName = airlineName;
        this.flightType = flightType;
        this.originCity = originCity;
        this.originAirport = originAirport;
        this.destinationCity = destinationCity;
        this.destinationAirport = destinationAirport;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.durationMinutes = durationMinutes;
        this.economyFare = economyFare;
        this.businessFare = businessFare;
        this.totalSeats = totalSeats;
        this.availableSeats = availableSeats;
    }

    public int getFlightId() { return flightId; }
    public void setFlightId(int flightId) { this.flightId = flightId; }

    public String getFlightNumber() { return flightNumber; }
    public void setFlightNumber(String flightNumber) { this.flightNumber = flightNumber; }

    public String getAirlineName() { return airlineName; }
    public void setAirlineName(String airlineName) { this.airlineName = airlineName; }

    public String getFlightType() { return flightType; }
    public void setFlightType(String flightType) { this.flightType = flightType; }

    public String getOriginCity() { return originCity; }
    public void setOriginCity(String originCity) { this.originCity = originCity; }

    public String getOriginAirport() { return originAirport; }
    public void setOriginAirport(String originAirport) { this.originAirport = originAirport; }

    public String getDestinationCity() { return destinationCity; }
    public void setDestinationCity(String destinationCity) { this.destinationCity = destinationCity; }

    public String getDestinationAirport() { return destinationAirport; }
    public void setDestinationAirport(String destinationAirport) { this.destinationAirport = destinationAirport; }

    public String getDepartureTime() { return departureTime; }
    public void setDepartureTime(String departureTime) { this.departureTime = departureTime; }

    public String getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(String arrivalTime) { this.arrivalTime = arrivalTime; }

    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }

    public double getEconomyFare() { return economyFare; }
    public void setEconomyFare(double economyFare) { this.economyFare = economyFare; }

    public double getBusinessFare() { return businessFare; }
    public void setBusinessFare(double businessFare) { this.businessFare = businessFare; }

    public int getTotalSeats() { return totalSeats; }
    public void setTotalSeats(int totalSeats) { this.totalSeats = totalSeats; }

    public int getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(int availableSeats) { this.availableSeats = availableSeats; }
}