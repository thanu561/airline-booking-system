package com.airline.dsa;

import com.airline.model.Flight;
import java.util.ArrayList;
import java.util.List;

/**
 * DSA CONCEPT: SEARCHING ALGORITHMS
 * 1. Binary Search: O(log N) search on flights sorted by Flight ID or Fare.
 * 2. Multi-Attribute Filter Search: Linear / Indexed search matching origin,
 *    destination, flight type, and date.
 */
public class FlightSearchEngine {

    /**
     * Binary Search: Locates a flight by flightId in an array sorted by flightId.
     * Time Complexity: O(log N)
     */
    public static Flight binarySearchById(Flight[] sortedFlights, int targetFlightId) {
        if (sortedFlights == null || sortedFlights.length == 0) return null;
        int low = 0;
        int high = sortedFlights.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            int midVal = sortedFlights[mid].getFlightId();

            if (midVal == targetFlightId) {
                return sortedFlights[mid];
            } else if (midVal < targetFlightId) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null;
    }

    /**
     * Binary Search: Finds all flights with economy fare <= maxBudget in a fare-sorted array.
     * Uses binary search to find the partition point in O(log N).
     */
    public static List<Flight> binarySearchByMaxFare(Flight[] sortedByFare, double maxBudget) {
        List<Flight> result = new ArrayList<>();
        if (sortedByFare == null || sortedByFare.length == 0) return result;

        int low = 0;
        int high = sortedByFare.length - 1;
        int ceilingIndex = -1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (sortedByFare[mid].getEconomyFare() <= maxBudget) {
                ceilingIndex = mid;
                low = mid + 1; // Try to find larger index with valid fare
            } else {
                high = mid - 1;
            }
        }

        if (ceilingIndex != -1) {
            for (int i = 0; i <= ceilingIndex; i++) {
                result.add(sortedByFare[i]);
            }
        }
        return result;
    }

    /**
     * Multi-Attribute Search / Filter on flight array:
     * Origin, Destination, FlightType (DOMESTIC/INTERNATIONAL), Max Fare, etc.
     */
    public static List<Flight> filterFlights(Flight[] flights, String origin, String destination,
                                            String flightType, Double maxFare, String travelClass) {
        List<Flight> matches = new ArrayList<>();
        if (flights == null) return matches;

        for (Flight f : flights) {
            boolean originMatch = (origin == null || origin.trim().isEmpty() ||
                    "ALL".equalsIgnoreCase(origin.trim()) ||
                    f.getOriginCity().equalsIgnoreCase(origin.trim()) ||
                    f.getOriginAirport().equalsIgnoreCase(origin.trim()));

            boolean destMatch = (destination == null || destination.trim().isEmpty() ||
                    "ALL".equalsIgnoreCase(destination.trim()) ||
                    f.getDestinationCity().equalsIgnoreCase(destination.trim()) ||
                    f.getDestinationAirport().equalsIgnoreCase(destination.trim()));

            boolean typeMatch = (flightType == null || flightType.trim().isEmpty() ||
                    "ALL".equalsIgnoreCase(flightType.trim()) ||
                    f.getFlightType().equalsIgnoreCase(flightType.trim()));

            double fareToCheck = "BUSINESS".equalsIgnoreCase(travelClass) ? f.getBusinessFare() : f.getEconomyFare();
            boolean fareMatch = (maxFare == null || maxFare <= 0 || fareToCheck <= maxFare);

            if (originMatch && destMatch && typeMatch && fareMatch) {
                matches.add(f);
            }
        }
        return matches;
    }
}