package com.airline.dao;

import com.airline.config.DbConfig;
import com.airline.model.Meal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MealDao {

    public List<Meal> getAllMeals() {
        List<Meal> list = new ArrayList<>();
        String sql = "SELECT * FROM meals ORDER BY price ASC";
        try (Connection conn = DbConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapResultSetToMeal(rs));
            }
        } catch (Exception e) {
            System.err.println("[MealDao] Error fetching meals from DB: " + e.getMessage());
            return getDefaultMeals();
        }
        return list.isEmpty() ? getDefaultMeals() : list;
    }

    public Meal getMealById(int mealId) {
        String sql = "SELECT * FROM meals WHERE meal_id = ?";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, mealId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToMeal(rs);
                }
            }
        } catch (Exception e) {
            System.err.println("[MealDao] Error getting meal by ID: " + e.getMessage());
        }
        for (Meal m : getDefaultMeals()) {
            if (m.getMealId() == mealId) return m;
        }
        return null;
    }

    private Meal mapResultSetToMeal(ResultSet rs) throws Exception {
        return new Meal(
                rs.getInt("meal_id"),
                rs.getString("meal_name"),
                rs.getString("meal_type"),
                rs.getDouble("price"),
                rs.getString("description")
        );
    }

    public static List<Meal> getDefaultMeals() {
        List<Meal> defaultMeals = new ArrayList<>();
        defaultMeals.add(new Meal(1, "No In-Flight Meal", "SPECIAL", 0.00, "Complimentary packaged mineral water on board"));
        defaultMeals.add(new Meal(2, "Royal Indian Thali", "VEG", 350.00, "Fragrant basmati rice, paneer butter masala, dal makhani, warm rotis & gulab jamun"));
        defaultMeals.add(new Meal(3, "South Indian Tiffin Combo", "VEG", 280.00, "Steaming idlis, crispy medu vada, masala dosa with sambar and coconut chutney"));
        defaultMeals.add(new Meal(4, "Hyderabadi Dum Biryani", "NON_VEG", 490.00, "Aromatic basmati rice cooked with spiced tender chicken and mirchi ka salan"));
        defaultMeals.add(new Meal(5, "Continental Breakfast Tray", "NON_VEG", 420.00, "Fluffy masala omelette, hash browns, chicken sausages, warm croissant & butter"));
        defaultMeals.add(new Meal(6, "Asian Superfood Salad Bowl", "VEG", 380.00, "Tofu, edamame, crisp greens, roasted almonds, and sesame ginger dressing"));
        defaultMeals.add(new Meal(7, "Mutton Rogan Josh Gourmet Platter", "NON_VEG", 650.00, "Kashmiri braised mutton with saffron pulao and garlic naan"));
        defaultMeals.add(new Meal(8, "Masala Chai & Snack Combo", "BEVERAGE", 180.00, "Freshly brewed ginger cardamom tea served with hot samosas & cashew cookies"));
        return defaultMeals;
    }
}