package com.airline.model;

public class Seat {
    private int seatId;
    private int flightId;
    private String seatNumber;
    private String seatClass; // ECONOMY or BUSINESS
    private boolean isBooked;
    private String bookedPnr;

    public Seat() {}

    public Seat(int seatId, int flightId, String seatNumber, String seatClass, boolean isBooked, String bookedPnr) {
        this.seatId = seatId;
        this.flightId = flightId;
        this.seatNumber = seatNumber;
        this.seatClass = seatClass;
        this.isBooked = isBooked;
        this.bookedPnr = bookedPnr;
    }

    public int getSeatId() { return seatId; }
    public void setSeatId(int seatId) { this.seatId = seatId; }

    public int getFlightId() { return flightId; }
    public void setFlightId(int flightId) { this.flightId = flightId; }

    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }

    public String getSeatClass() { return seatClass; }
    public void setSeatClass(String seatClass) { this.seatClass = seatClass; }

    public boolean isBooked() { return isBooked; }
    public void setBooked(boolean booked) { isBooked = booked; }

    public String getBookedPnr() { return bookedPnr; }
    public void setBookedPnr(String bookedPnr) { this.bookedPnr = bookedPnr; }
}