package com.airline;

import com.airline.config.DbConfig;
import com.airline.server.AirlineHttpServer;

public class Main {
    public static void main(String[] args) {
        System.out.println("==================================================================");
        System.out.println("   WELCOME TO SKYLINE AIRLINE RESERVATION & MANAGEMENT SYSTEM     ");
        System.out.println("   Stack: HTML5/CSS3/JS + Java Core (HttpServer) + JDBC + MySQL   ");
        System.out.println("   DSA: Array, Queue, Priority Queue, Binary Search, Merge & Quick Sort");
        System.out.println("==================================================================");

        // 1. Initialize Database Schema & Connection Check
        DbConfig.initializeDatabase();

        // 2. Start HTTP Server
        int port = DbConfig.getServerPort();
        try {
            AirlineHttpServer server = new AirlineHttpServer(port);
            server.start();

            // Keep process active and handle shutdown hook gracefully
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                System.out.println("\n[Main] Stopping Airline HTTP Server...");
                server.stop();
                System.out.println("[Main] Server stopped cleanly.");
            }));

        } catch (Exception e) {
            System.err.println("[Main] Fatal: Failed to start Airline HTTP Server on port " + port + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
}