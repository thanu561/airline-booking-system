package com.airline.server;

import com.airline.config.DbConfig;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.util.concurrent.Executors;

public class AirlineHttpServer {
    private final int port;
    private HttpServer server;

    public AirlineHttpServer(int port) {
        this.port = port;
    }

    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(port), 0);
        server.setExecutor(Executors.newFixedThreadPool(16));

        // Register API Handlers
        server.createContext("/api/flights/binary-search", new ApiHandlers.BinarySearchHandler());
        server.createContext("/api/flights", new ApiHandlers.FlightsHandler());
        server.createContext("/api/seats", new ApiHandlers.SeatsHandler());
        server.createContext("/api/meals", new ApiHandlers.MealsHandler());
        server.createContext("/api/book", new ApiHandlers.BookHandler());
        server.createContext("/api/cancel", new ApiHandlers.CancelHandler());
        server.createContext("/api/history", new ApiHandlers.HistoryHandler());
        server.createContext("/api/notifications", new ApiHandlers.NotificationsHandler());
        server.createContext("/api/dsa-stats", new ApiHandlers.DsaStatsHandler());

        // Static Web Resource Handler
        server.createContext("/", new StaticFileHandler("web"));

        server.start();
        System.out.println("==================================================================");
        System.out.println("  SKYLINE AIRWAYS SERVER RUNNING AT: http://localhost:" + port);
        System.out.println("  Open your browser and navigate to http://localhost:" + port);
        System.out.println("==================================================================");
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
        }
    }

    public static class StaticFileHandler implements HttpHandler {
        private final String rootDirectory;

        public StaticFileHandler(String rootDirectory) {
            this.rootDirectory = rootDirectory;
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if ("/".equals(path) || path.isEmpty()) {
                path = "/index.html";
            }

            File file = new File(rootDirectory + path).getCanonicalFile();
            File root = new File(rootDirectory).getCanonicalFile();

            // Prevent path traversal
            if (!file.getPath().startsWith(root.getPath()) || !file.exists() || file.isDirectory()) {
                file = new File(rootDirectory + "/index.html");
            }

            if (!file.exists()) {
                String notFound = "404 Not Found";
                exchange.sendResponseHeaders(404, notFound.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(notFound.getBytes());
                }
                return;
            }

            String contentType = determineContentType(file.getName());
            exchange.getResponseHeaders().set("Content-Type", contentType);
            exchange.getResponseHeaders().set("Cache-Control", "no-cache, no-store, must-revalidate");
            exchange.sendResponseHeaders(200, file.length());

            try (OutputStream os = exchange.getResponseBody();
                 FileInputStream fis = new FileInputStream(file)) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = fis.read(buffer)) > 0) {
                    os.write(buffer, 0, count);
                }
            }
        }

        private String determineContentType(String fileName) {
            String lower = fileName.toLowerCase();
            if (lower.endsWith(".html")) return "text/html; charset=UTF-8";
            if (lower.endsWith(".css")) return "text/css; charset=UTF-8";
            if (lower.endsWith(".js")) return "application/javascript; charset=UTF-8";
            if (lower.endsWith(".json")) return "application/json; charset=UTF-8";
            if (lower.endsWith(".png")) return "image/png";
            if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
            if (lower.endsWith(".svg")) return "image/svg+xml";
            if (lower.endsWith(".ico")) return "image/x-icon";
            return "text/plain; charset=UTF-8";
        }
    }
}