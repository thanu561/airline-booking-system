package com.airline.service;

import com.airline.dao.NotificationDao;
import com.airline.model.Booking;
import com.airline.model.Flight;
import com.airline.model.Notification;
import java.util.List;

public class NotificationService {
    private final NotificationDao notificationDao = new NotificationDao();

    public void notifyBookingConfirmed(Booking booking, String seatNumber, String mealName) {
        String subject = "Booking Confirmed: PNR " + booking.getPnr();
        String msg = "Congratulations " + booking.getContactName() + "! Your flight reservation (PNR: " +
                booking.getPnr() + ") is CONFIRMED on " + booking.getTravelDate() + " for flight #" +
                (booking.getFlight() != null ? booking.getFlight().getFlightNumber() : booking.getFlightId()) +
                ". Assigned Seat: " + (seatNumber != null ? seatNumber : "Auto-allocated") +
                ". Meal Selected: " + (mealName != null ? mealName : "None") +
                ". Total Paid: ₹" + String.format("%,.2f", booking.getTotalAmount()) + ". Have a safe flight!";

        notificationDao.createNotification(new Notification(
                0, booking.getPnr(), booking.getContactEmail(), "BOOKING_CONFIRMED", subject, msg, false, null
        ));
    }

    public void notifyWaitingListAssigned(Booking booking, int wlPos) {
        String subject = "Waiting List Notice: PNR " + booking.getPnr() + " (Position: WL-" + wlPos + ")";
        String msg = "Dear " + booking.getContactName() + ", flight capacity is currently full. Your reservation (PNR: " +
                booking.getPnr() + ") has been queued in the WAITING LIST at Position WL-" + wlPos +
                ". Total Paid: ₹" + String.format("%,.2f", booking.getTotalAmount()) +
                ". You will be automatically confirmed and notified as soon as any seat is released.";

        notificationDao.createNotification(new Notification(
                0, booking.getPnr(), booking.getContactEmail(), "WAITING_LIST_ASSIGNED", subject, msg, false, null
        ));
    }

    public void notifyBookingCancelled(Booking booking, double refundAmount) {
        String subject = "Booking Cancelled: PNR " + booking.getPnr();
        String msg = "Hello " + booking.getContactName() + ", your booking (PNR: " + booking.getPnr() +
                ") has been successfully cancelled. A refund of ₹" + String.format("%,.2f", refundAmount) +
                " (after 10% processing deduction) has been credited back to your original payment method.";

        notificationDao.createNotification(new Notification(
                0, booking.getPnr(), booking.getContactEmail(), "BOOKING_CANCELLED", subject, msg, false, null
        ));
    }

    public void notifyWaitingListPromoted(Booking promotedBooking, String seatNumber) {
        String subject = "GOOD NEWS: Waiting List Cleared for PNR " + promotedBooking.getPnr();
        String msg = "Great news " + promotedBooking.getContactName() + "! A seat has opened up and your waiting list reservation (PNR: " +
                promotedBooking.getPnr() + ") has been PROMOTED to CONFIRMED! Your assigned seat is: " + seatNumber +
                ". We look forward to welcoming you aboard.";

        notificationDao.createNotification(new Notification(
                0, promotedBooking.getPnr(), promotedBooking.getContactEmail(), "WAITING_LIST_PROMOTED", subject, msg, false, null
        ));
    }

    public void notifyLowSeatAvailability(Flight flight, int remainingSeats) {
        String subject = "High Demand Alert: Flight " + flight.getFlightNumber();
        String msg = "Hurry! Flight " + flight.getFlightNumber() + " (" + flight.getOriginCity() + " to " +
                flight.getDestinationCity() + ") has only " + remainingSeats + " seats remaining.";

        notificationDao.createNotification(new Notification(
                0, "SYSTEM-ALERT", "all-passengers@skyline.com", "SEAT_ALERT", subject, msg, false, null
        ));
    }

    public List<Notification> getRecentNotifications(int limit) {
        return notificationDao.getRecentNotifications(limit);
    }

    public List<Notification> getNotificationsByPnr(String pnr) {
        return notificationDao.getNotificationsByPnr(pnr);
    }
}