package com.airline.model;

public class Notification {
    private int notificationId;
    private String pnr;
    private String recipientEmail;
    private String eventType; // BOOKING_CONFIRMED, WAITING_LIST_ASSIGNED, BOOKING_CANCELLED, WAITING_LIST_PROMOTED, SEAT_ALERT
    private String subject;
    private String message;
    private boolean isRead;
    private String createdAt;

    public Notification() {}

    public Notification(int notificationId, String pnr, String recipientEmail, String eventType,
                        String subject, String message, boolean isRead, String createdAt) {
        this.notificationId = notificationId;
        this.pnr = pnr;
        this.recipientEmail = recipientEmail;
        this.eventType = eventType;
        this.subject = subject;
        this.message = message;
        this.isRead = isRead;
        this.createdAt = createdAt;
    }

    public int getNotificationId() { return notificationId; }
    public void setNotificationId(int notificationId) { this.notificationId = notificationId; }

    public String getPnr() { return pnr; }
    public void setPnr(String pnr) { this.pnr = pnr; }

    public String getRecipientEmail() { return recipientEmail; }
    public void setRecipientEmail(String recipientEmail) { this.recipientEmail = recipientEmail; }

    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public boolean isRead() { return isRead; }
    public void setRead(boolean read) { isRead = read; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}