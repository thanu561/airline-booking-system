package com.airline.model;

public class Meal {
    private int mealId;
    private String mealName;
    private String mealType;
    private double price;
    private String description;

    public Meal() {}

    public Meal(int mealId, String mealName, String mealType, double price, String description) {
        this.mealId = mealId;
        this.mealName = mealName;
        this.mealType = mealType;
        this.price = price;
        this.description = description;
    }

    public int getMealId() { return mealId; }
    public void setMealId(int mealId) { this.mealId = mealId; }

    public String getMealName() { return mealName; }
    public void setMealName(String mealName) { this.mealName = mealName; }

    public String getMealType() { return mealType; }
    public void setMealType(String mealType) { this.mealType = mealType; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}