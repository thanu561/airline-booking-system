# ✈️ Skyline Airways - Complete Airline Booking System

A full-stack, enterprise-grade Airline Booking & Management System engineered with:
- Fast, responsive HTML5, CSS3 & JavaScript frontend.
- Pure Java Core (com.sun.net.httpserver.HttpServer) + JDBC backend, zuro heavy framework bloat.
- MySQL 8.0+ database (mysql-connector-j-8.4.0.jar bundled).
- Custom DSA: Array, 2D Seat Matrix, FIFO Queue, Max-Heap Priority Queue, Binary Search, Merge Sort, Quick Sort.

---

## 🌟 Core Features

1. *Domestic & Internatimonal Flights:*
   - Domestic routes (JFK → LAX, ORD → MIA, DEL ↊ BOM, BLR↊ DEL, DPW → DEN)
   - International routes (JFK → LHR, DXB ↊ JFK, SIN → NRT, CDG → SFO, DEL ↊ ORD, FRA → BLR)
2. *Any-Date Flight Search & Filtering:*
   - Search by origin, destination, departure date, flight category, and cabin class (Economy / Business).
3. *Interactive Seat Map (DSA 2D Matrix):*
   - Visual Cockpit, Business Class (Rows 1-2, 2x2) and Economy Class (Rows 3-8, 2x2).
   - Real-time status: Available (blue), Booked (red), Selected (emerald green).
4. *Traveller Details & Identity Verification:*
   - Records full name, age, gender, contact email, phone, and Government ID / Passport number (mandatory for international itineraries).
5. *In-Flight Meal Selection & Live Price Calculation:*
   - Curated in-flight menu with fixed prices:
     * *Asian Vegetarian Thali* ($12.00)
     * *Continental Breakfast Platter* ($14.50)
     * *Mediterranean Grilled Chicken* ($18.00)
     * *Vegan Superfood Gourmet Bowl* ($15.00)
     * *Halal Lamb & Saffron Biryani* ($19.50)
     * *Kosher Salmon Fillet* ($22.00)
     * *Artisan Beverage & Snack Combo* ($6.50)
     * *Complimentary Water* ($0.00)
   - *Automatic Total Calculation:* Base Fare + Meal Price + Taxes = Grand Total dynamically calculated!
6. *Waiting List System (FIFO Queue & Max-Heap Priority Queue):*
   - When a flight is fully booked, passengers are placed onto the Waiting List (guaranteed position WL-1, WL-2).
   - Senior citizens (60+), VIP travelers, and Business class are placed in a *Binary Max-Heap Priority Queue* for elevated priority!
7. *Cancellation & Automatic Waiting List Promotion:*
   - Cancel tickets anytime using PNR with automatic 90% refund calculation.
   - When a confirmed seat is released, the system *automatically promotes the highest priority waiting list passenger to CONFIRMED*, reallocates the seat, and dispatches a promotion alert!
8. *PNR Status & Booking History:*
   - Track booking status anytime using PNR (e.g. SKY-77821) or registered email.
9. *Real-time Notifications:*
   - Instant event alerts for Bookings, Waiting List, Cancellations, and Promotions.
---

## 🧨 Data Structures & Algorithms (DSA)

1. *Array & 2D Matrix* (`com.airline.dsa.FlightArray`& `SeatMatrix`)
   - Dynamic flight array; 8x4 2D aircraft cabin matrix providing O(1) seat state checks and reservations.
2. *Queue (FIFO)* (`com.airline.dsa.WaitingListQueue`)
   - Custom singly-linked FIFO queue for standard waiting list management (O(1) Enqueue & Dequeue).
3. *Priority Queue (Max-Heap)* (`com.airline.dsa.PriorityWaitingList`)
   - Binary Max-Heap for Seniors (60+), VIPs, and Business class passengers (O(1) Peek, O(log N) Insert & ExtractMax).
4. *Searching (Binary Search)* (`com.airline.dsa.FlightSearchEngine`)
   - O((og N) binary search on sorted flights by flight ID and by far ceilings.
5. *Sorting (Merge Sort & Quick Sort)* (`com.airline.dsa.FlightSorter`)
   - Merge Sort: Stable O(N log N) sorting by flight fares.
   - Quick Sort: O(N log N) partition sorting by duration and departure times.
---

## 🚀 One-Click Execution

1. Double-click `run.bat` (on Windows) or run `./run.sh` (on Linux/macOS).
2. Open http://localhost:8080 in any web browser!
---
