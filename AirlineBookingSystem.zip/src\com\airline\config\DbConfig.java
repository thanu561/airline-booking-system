package com.airline.config;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

/**
 * Database connection manager with automatic schema initialization & resilience.
 */
public class DbConfig {
    private static String dbUrl = "jdbc:mysql://localhost:3306/airline_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&createDatabaseIfNotExist=true";
    private static String dbUser = "root";
    private static String dbPassword = "root";
    private static int serverPort = 8080;
    private static boolean isInitialized = false;

    static {
        loadProperties();
    }

    public static void loadProperties() {
        try {
            File propFile = new File("config/db.properties");
            if (propFile.exists()) {
                Properties props = new Properties();
                try (FileInputStream fis = new FileInputStream(propFile)) {
                    props.load(fis);
                    if (props.getProperty("db.url") != null) dbUrl = props.getProperty("db.url");
                    if (props.getProperty("db.user") != null) dbUser = props.getProperty("db.user");
                    if (props.getProperty("db.password") != null) dbPassword = props.getProperty("db.password");
                    if (props.getProperty("server.port") != null) serverPort = Integer.parseInt(props.getProperty("server.port"));
                }
                System.out.println("[DbConfig] Loaded configuration from " + propFile.getAbsolutePath());
            } else {
                System.out.println("[DbConfig] config/db.properties not found, using default credentials (root/root).");
            }
        } catch (Exception e) {
            System.err.println("[DbConfig] Warning loading db.properties: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(dbUrl, dbUser, dbPassword);
    }

    public static int getServerPort() {
        return serverPort;
    }

    /**
     * Verifies if MySQL schema is initialized. If not, auto-executes airline_schema.sql.
     */
    public static synchronized void initializeDatabase() {
        if (isInitialized) return;
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            boolean tablesExist = false;
            try (ResultSet rs = stmt.executeQuery("SHOW TABLES LIKE 'flights'")) {
                if (rs.next()) {
                    tablesExist = true;
                }
            }

            if (!tablesExist) {
                System.out.println("[DbConfig] Tables not detected. Auto-executing database/airline_schema.sql...");
                File sqlFile = new File("database/airline_schema.sql");
                if (sqlFile.exists()) {
                    executeSqlScript(conn, sqlFile);
                    System.out.println("[DbConfig] Database initialized successfully from airline_schema.sql.");
                } else {
                    System.err.println("[DbConfig] Warning: database/airline_schema.sql not found!");
                }
            } else {
                System.out.println("[DbConfig] MySQL Database connected & schema verified.");
            }
            isInitialized = true;
        } catch (Exception e) {
            System.err.println("[DbConfig] Note: Direct MySQL connection error: " + e.getMessage());
            System.err.println("[DbConfig] Please ensure MySQL is running on localhost:3306 with credentials in config/db.properties.");
        }
    }

    private static void executeSqlScript(Connection conn, File sqlFile) {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(sqlFile), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            boolean inDelimiter = false;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("--") || line.startsWith("//")) continue;
                if (line.startsWith("DELIMITER")) {
                    inDelimiter = !inDelimiter;
                    continue;
                }
                sb.append(line).append(" ");
                if (!inDelimiter && line.endsWith(";")) {
                    String query = sb.toString().trim();
                    if (!query.isEmpty()) {
                        try (Statement st = conn.createStatement()) {
                            st.execute(query);
                        } catch (Exception ex) {
                            // Ignored if non-fatal
                        }
                    }
                    sb.setLength(0);
                }
            }
        } catch (Exception e) {
            System.err.println("[DbConfig] Script execution notice: " + e.getMessage());
        }
    }
}