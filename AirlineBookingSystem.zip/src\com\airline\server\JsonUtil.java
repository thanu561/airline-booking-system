package com.airline.server;

import com.airline.model.Booking;
import com.airline.model.Flight;
import com.airline.model.Meal;
import com.airline.model.Notification;
import com.airline.model.Passenger;
import com.airline.model.Seat;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Pure Java JSON formatting utility with ZERO external dependencies.
 */
public class JsonUtil {

    public static String toJson(Object obj) {
        if (obj == null) return "null";
        if (obj instanceof String) return quote((String) obj);
        if (obj instanceof Number || obj instanceof Boolean) return String.valueOf(obj);
        if (obj instanceof Flight) return flightToJson((Flight) obj);
        if (obj instanceof Seat) return seatToJson((Seat) obj);
        if (obj instanceof Meal) return mealToJson((Meal) obj);
        if (obj instanceof Passenger) return passengerToJson((Passenger) obj);
        if (obj instanceof Booking) return bookingToJson((Booking) obj);
        if (obj instanceof Notification) return notificationToJson((Notification) obj);
        if (obj instanceof List) return listToJson((List<?>) obj);
        if (obj instanceof Map) return mapToJson((Map<?, ?>) obj);
        return quote(obj.toString());
    }

    public static String flightToJson(Flight f) {
        if (f == null) return "null";
        return "{" +
                "\"flightId\":" + f.getFlightId() + "," +
                "\"flightNumber\":" + quote(f.getFlightNumber()) + "," +
                "\"airlineName\":" + quote(f.getAirlineName()) + "," +
                "\"flightType\":" + quote(f.getFlightType()) + "," +
                "\"originCity\":" + quote(f.getOriginCity()) + "," +
                "\"originAirport\":" + quote(f.getOriginAirport()) + "," +
                "\"destinationCity\":" + quote(f.getDestinationCity()) + "," +
                "\"destinationAirport\":" + quote(f.getDestinationAirport()) + "," +
                "\"departureTime\":" + quote(f.getDepartureTime()) + "," +
                "\"arrivalTime\":" + quote(f.getArrivalTime()) + "," +
                "\"durationMinutes\":" + f.getDurationMinutes() + "," +
                "\"economyFare\":" + f.getEconomyFare() + "," +
                "\"businessFare\":" + f.getBusinessFare() + "," +
                "\"totalSeats\":" + f.getTotalSeats() + "," +
                "\"availableSeats\":" + f.getAvailableSeats() +
                "}";
    }

    public static String seatToJson(Seat s) {
        if (s == null) return "null";
        return "{" +
                "\"seatId\":" + s.getSeatId() + "," +
                "\"flightId\":" + s.getFlightId() + "," +
                "\"seatNumber\":" + quote(s.getSeatNumber()) + "," +
                "\"seatClass\":" + quote(s.getSeatClass()) + "," +
                "\"isBooked\":" + s.isBooked() + "," +
                "\"bookedPnr\":" + (s.getBookedPnr() != null ? quote(s.getBookedPnr()) : "null") +
                "}";
    }

    public static String mealToJson(Meal m) {
        if (m == null) return "null";
        return "{" +
                "\"mealId\":" + m.getMealId() + "," +
                "\"mealName\":" + quote(m.getMealName()) + "," +
                "\"mealType\":" + quote(m.getMealType()) + "," +
                "\"price\":" + m.getPrice() + "," +
                "\"description\":" + quote(m.getDescription()) +
                "}";
    }

    public static String passengerToJson(Passenger p) {
        if (p == null) return "null";
        return "{" +
                "\"passengerId\":" + p.getPassengerId() + "," +
                "\"pnr\":" + quote(p.getPnr()) + "," +
                "\"fullName\":" + quote(p.getFullName()) + "," +
                "\"age\":" + p.getAge() + "," +
                "\"gender\":" + quote(p.getGender()) + "," +
                "\"idPassportNumber\":" + quote(p.getIdPassportNumber()) + "," +
                "\"seatNumber\":" + quote(p.getSeatNumber()) + "," +
                "\"mealId\":" + p.getMealId() + "," +
                "\"mealName\":" + quote(p.getMealName()) + "," +
                "\"mealPrice\":" + p.getMealPrice() + "," +
                "\"isPriority\":" + p.isPriority() + "," +
                "\"priorityScore\":" + p.getPriorityScore() +
                "}";
    }

    public static String bookingToJson(Booking b) {
        if (b == null) return "null";
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"bookingId\":").append(b.getBookingId()).append(",");
        sb.append("\"pnr\":").append(quote(b.getPnr())).append(",");
        sb.append("\"flightId\":").append(b.getFlightId()).append(",");
        sb.append("\"travelDate\":").append(quote(b.getTravelDate())).append(",");
        sb.append("\"travelClass\":").append(quote(b.getTravelClass())).append(",");
        sb.append("\"contactName\":").append(quote(b.getContactName())).append(",");
        sb.append("\"contactEmail\":").append(quote(b.getContactEmail())).append(",");
        sb.append("\"contactPhone\":").append(quote(b.getContactPhone())).append(",");
        sb.append("\"totalAmount\":").append(b.getTotalAmount()).append(",");
        sb.append("\"status\":").append(quote(b.getStatus())).append(",");
        sb.append("\"wlPosition\":").append(b.getWlPosition() != null ? b.getWlPosition() : "null").append(",");
        sb.append("\"createdAt\":").append(quote(b.getCreatedAt())).append(",");
        sb.append("\"flight\":").append(flightToJson(b.getFlight())).append(",");
        sb.append("\"passengers\":").append(listToJson(b.getPassengers()));
        sb.append("}");
        return sb.toString();
    }

    public static String notificationToJson(Notification n) {
        if (n == null) return "null";
        return "{" +
                "\"notificationId\":" + n.getNotificationId() + "," +
                "\"pnr\":" + quote(n.getPnr()) + "," +
                "\"recipientEmail\":" + quote(n.getRecipientEmail()) + "," +
                "\"eventType\":" + quote(n.getEventType()) + "," +
                "\"subject\":" + quote(n.getSubject()) + "," +
                "\"message\":" + quote(n.getMessage()) + "," +
                "\"isRead\":" + n.isRead() + "," +
                "\"createdAt\": \"" + (n.getCreatedAt() != null ? n.getCreatedAt() : "") + "\"" +
                "}";
    }

    public static String listToJson(List<?> list) {
        if (list == null) return "[]";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            sb.append(toJson(list.get(i)));
            if (i < list.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    public static String mapToJson(Map<?, ?> map) {
        if (map == null) return "{}";
        StringBuilder sb = new StringBuilder("{");
        int count = 0;
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            if (count > 0) sb.append(",");
            sb.append(quote(String.valueOf(entry.getKey()))).append(":").append(toJson(entry.getValue()));
            count++;
        }
        sb.append("}");
        return sb.toString();
    }

    private static String quote(String string) {
        if (string == null) return "\"\"";
        return "\"" + string.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\b", "\\b")
                .replace("\f", "\\f")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t") + "\"";
    }

    /**
     * Simple JSON field extractor for primitive/string values without external libraries.
     */
    public static Map<String, String> parseSimpleJson(String json) {
        Map<String, String> map = new HashMap<>();
        if (json == null || json.trim().isEmpty()) return map;
        String content = json.trim();
        if (content.startsWith("{") && content.endsWith("}")) {
            content = content.substring(1, content.length() - 1);
        }

        // Basic tokenization respecting quoted strings
        boolean inQuotes = false;
        StringBuilder token = new StringBuilder();
        List<String> pairs = new java.util.ArrayList<>();

        for (int i = 0; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == '\"' && (i == 0 || content.charAt(i - 1) != '\\')) {
                inQuotes = !inQuotes;
            }
            if (c == ',' && !inQuotes) {
                pairs.add(token.toString().trim());
                token.setLength(0);
            } else {
                token.append(c);
            }
        }
        if (token.length() > 0) {
            pairs.add(token.toString().trim());
        }

        for (String pair : pairs) {
            int colonIdx = pair.indexOf(':');
            if (colonIdx > 0) {
                String key = cleanValue(pair.substring(0, colonIdx));
                String val = cleanValue(pair.substring(colonIdx + 1));
                map.put(key, val);
            }
        }
        return map;
    }

    private static String cleanValue(String val) {
        if (val == null) return "";
        val = val.trim();
        if (val.startsWith("\"") && val.endsWith("\"") && val.length() >= 2) {
            val = val.substring(1, val.length() - 1);
        }
        return val;
    }
}