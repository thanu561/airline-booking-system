package com.airline.dsa;

import com.airline.model.Booking;
import java.util.ArrayList;
import java.util.List;

/**
 * DSA CONCEPT: QUEUE (FIFO - First-In First-Out)
 * Used for standard flight waiting list management.
 * When confirmed tickets are cancelled, the passenger at the front of the queue
 * is automatically promoted to CONFIRMED.
 */
public class WaitingListQueue {

    private static class Node {
        Booking booking;
        Node next;

        Node(Booking booking) {
            this.booking = booking;
            this.next = null;
        }
    }

    private Node front;
    private Node rear;
    private int count;

    public WaitingListQueue() {
        this.front = null;
        this.rear = null;
        this.count = 0;
    }

    /**
     * Enqueue: Adds a booking to the back of the waiting list. O(1)
     */
    public synchronized void enqueue(Booking booking) {
        if (booking == null) return;
        Node newNode = new Node(booking);
        if (rear == null) {
            front = rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
        count++;
        booking.setWlPosition(count);
    }

    /**
     * Dequeue: Retrieves and removes the first booking in the waiting list. O(1)
     */
    public synchronized Booking dequeue() {
        if (isEmpty()) {
            return null;
        }
        Node temp = front;
        front = front.next;
        if (front == null) {
            rear = null;
        }
        count--;
        recalculatePositions();
        return temp.booking;
    }

    /**
     * Peek: Looks at the front element without removing it. O(1)
     */
    public synchronized Booking peek() {
        return isEmpty() ? null : front.booking;
    }

    public synchronized boolean isEmpty() {
        return front == null;
    }

    public synchronized int size() {
        return count;
    }

    /**
     * Remove a specific booking by PNR if traveler cancels waiting list. O(N)
     */
    public synchronized boolean removeByPnr(String pnr) {
        if (isEmpty() || pnr == null) return false;

        if (front.booking.getPnr().equalsIgnoreCase(pnr)) {
            dequeue();
            return true;
        }

        Node current = front;
        while (current.next != null) {
            if (current.next.booking.getPnr().equalsIgnoreCase(pnr)) {
                current.next = current.next.next;
                if (current.next == null) {
                    rear = current;
                }
                count--;
                recalculatePositions();
                return true;
            }
            current = current.next;
        }
        return false;
    }

    /**
     * Recalculates 1-based positions for remaining waiting list passengers.
     */
    private void recalculatePositions() {
        Node curr = front;
        int pos = 1;
        while (curr != null) {
            curr.booking.setWlPosition(pos++);
            curr = curr.next;
        }
    }

    /**
     * Returns all elements currently in the waiting list queue.
     */
    public synchronized List<Booking> toList() {
        List<Booking> list = new ArrayList<>();
        Node curr = front;
        while (curr != null) {
            list.add(curr.booking);
            curr = curr.next;
        }
        return list;
    }
}