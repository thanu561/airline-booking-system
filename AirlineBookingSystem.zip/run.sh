#!/bin/bash
echo "==================================================="
echo "  Starting Skyline Airline Booking System Server..."
echo "==================================================="

if [ ! -f "build/com/airline/Main.class" ]; then
    echo "Build directory not found. Compiling first..."
    chmod +x compile.sh
    ./compile.sh
fi

java -cp "build:lib/mysql-connector-j-8.4.0.jar" com.airline.Main