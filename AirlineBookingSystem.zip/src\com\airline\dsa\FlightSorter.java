package com.airline.dsa;

import com.airline.model.Flight;

/**
 * DSA CONCEPT: SORTING ALGORITHMS
 * 1. Merge Sort: Stable O(N log N) divide-and-conquer sorting for Fares.
 * 2. Quick Sort: In-place O(N log N) divide-and-conquer sorting for Duration & Departure Time.
 */
public class FlightSorter {

    // =========================================================================
    // MERGE SORT: Sort by Fare (Economy or Business)
    // Stable, O(N log N) guaranteed time complexity
    // =========================================================================
    public static void mergeSortByFare(Flight[] arr, boolean ascending, boolean isBusiness) {
        if (arr == null || arr.length <= 1) return;
        Flight[] temp = new Flight[arr.length];
        mergeSort(arr, temp, 0, arr.length - 1, ascending, isBusiness);
    }

    private static void mergeSort(Flight[] arr, Flight[] temp, int left, int right, boolean ascending, boolean isBusiness) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSort(arr, temp, left, mid, ascending, isBusiness);
            mergeSort(arr, temp, mid + 1, right, ascending, isBusiness);
            merge(arr, temp, left, mid, right, ascending, isBusiness);
        }
    }

    private static void merge(Flight[] arr, Flight[] temp, int left, int mid, int right, boolean ascending, boolean isBusiness) {
        for (int i = left; i <= right; i++) {
            temp[i] = arr[i];
        }

        int i = left;
        int j = mid + 1;
        int k = left;

        while (i <= mid && j <= right) {
            double fare1 = isBusiness ? temp[i].getBusinessFare() : temp[i].getEconomyFare();
            double fare2 = isBusiness ? temp[j].getBusinessFare() : temp[j].getEconomyFare();

            boolean condition = ascending ? (fare1 <= fare2) : (fare1 >= fare2);
            if (condition) {
                arr[k++] = temp[i++];
            } else {
                arr[k++] = temp[j++];
            }
        }

        while (i <= mid) {
            arr[k++] = temp[i++];
        }
    }

    // =========================================================================
    // QUICK SORT: Sort by Duration or Departure Time
    // In-place, O(N log N) average time complexity
    // =========================================================================
    public static void quickSortByDuration(Flight[] arr, boolean ascending) {
        if (arr == null || arr.length <= 1) return;
        quickSortDurationHelper(arr, 0, arr.length - 1, ascending);
    }

    private static void quickSortDurationHelper(Flight[] arr, int low, int high, boolean ascending) {
        if (low < high) {
            int pi = partitionDuration(arr, low, high, ascending);
            quickSortDurationHelper(arr, low, pi - 1, ascending);
            quickSortDurationHelper(arr, pi + 1, high, ascending);
        }
    }

    private static int partitionDuration(Flight[] arr, int low, int high, boolean ascending) {
        int pivot = arr[high].getDurationMinutes();
        int i = low - 1;

        for (int j = low; j < high; j++) {
            boolean condition = ascending ? (arr[j].getDurationMinutes() <= pivot) : (arr[j].getDurationMinutes() >= pivot);
            if (condition) {
                i++;
                Flight temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        Flight temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }

    public static void quickSortByDepartureTime(Flight[] arr, boolean ascending) {
        if (arr == null || arr.length <= 1) return;
        quickSortDepartureHelper(arr, 0, arr.length - 1, ascending);
    }

    private static void quickSortDepartureHelper(Flight[] arr, int low, int high, boolean ascending) {
        if (low < high) {
            int pi = partitionDeparture(arr, low, high, ascending);
            quickSortDepartureHelper(arr, low, pi - 1, ascending);
            quickSortDepartureHelper(arr, pi + 1, high, ascending);
        }
    }

    private static int partitionDeparture(Flight[] arr, int low, int high, boolean ascending) {
        String pivot = arr[high].getDepartureTime();
        int i = low - 1;

        for (int j = low; j < high; j++) {
            int cmp = arr[j].getDepartureTime().compareTo(pivot);
            boolean condition = ascending ? (cmp <= 0) : (cmp >= 0);
            if (condition) {
                i++;
                Flight temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        Flight temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }
}