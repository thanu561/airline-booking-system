-- ====================================================================
-- AIRLINE BOOKING SYSTEM - DATABASE SCHEMA & SEED DATA (INR CURRENCY)
-- Target Database: MySQL 8.0+
-- Currency: Indian Rupees (INR / ₹)
-- ====================================================================

CREATE DATABASE IF NOT EXISTS airline_db;
USE airline_db;

DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS passengers;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS seats;
DROP TABLE IF EXISTS meals;
DROP TABLE IF EXISTS flights;

CREATE TABLE flights (
    flight_id INT AUTO_INCREMENT PRIMARY KEY,
    flight_number VARCHAR(20) NOT NULL UNIQUE,
    airline_name VARCHAR(100) NOT NULL,
    flight_type ENUM('DOMESTIC', 'INTERNATIONAL') NOT NULL,
    origin_city VARCHAR(100) NOT NULL,
    origin_airport VARCHAR(10) NOT NULL,
    destination_city VARCHAR(100) NOT NULL,
    destination_airport VARCHAR(10) NOT NULL,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    duration_minutes INT NOT NULL,
    economy_fare DECIMAL(10, 2) NOT NULL,
    business_fare DECIMAL(10, 2) NOT NULL,
    total_seats INT NOT NULL DEFAULT 30,
    available_seats INT NOT NULL DEFAULT 30,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE seats (
    seat_id INT AUTO_INCREMENT PRIMARY KEY,
    flight_id INT NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    seat_class ENUM('ECONOMY', 'BUSINESS') NOT NULL DEFAULT 'ECONOMY',
    is_booked BOOLEAN NOT NULL DEFAULT FALSE,
    booked_pnr VARCHAR(20) DEFAULT NULL,
    FOREIGN KEY (flight_id) REFERENCES flights(flight_id) ON DELETE CASCADE,
    UNIQUE KEY uq_flight_seat (flight_id, seat_number)
);

CREATE TABLE meals (
    meal_id INT AUTO_INCREMENT PRIMARY KEY,
    meal_name VARCHAR(100) NOT NULL,
    meal_type ENUM('VEG', 'NON_VEG', 'SPECIAL', 'BEVERAGE') NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    description VARCHAR(255) NOT NULL
);

CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    pnr VARCHAR(20) NOT NULL UNIQUE,
    flight_id INT NOT NULL,
    travel_date DATE NOT NULL,
    travel_class ENUM('ECONOMY', 'BUSINESS') NOT NULL,
    contact_name VARCHAR(100) NOT NULL,
    contact_email VARCHAR(100) NOT NULL,
    contact_phone VARCHAR(20) NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('CONFIRMED', 'WAITING_LIST', 'CANCELLED') NOT NULL DEFAULT 'CONFIRMED',
    wl_position INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (flight_id) REFERENCES flights(flight_id)
);

CREATE TABLE passengers (
    passenger_id INT AUTO_INCREMENT PRIMARY KEY,
    pnr VARCHAR(20) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(10) NOT NULL,
    id_passport_number VARCHAR(50) NOT NULL,
    seat_number VARCHAR(10) DEFAULT NULL,
    meal_id INT DEFAULT NULL,
    is_priority BOOLEAN NOT NULL DEFAULT FALSE,
    priority_score INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pnr) REFERENCES bookings(pnr) ON DELETE CASCADE,
    FOREIGN KEY (meal_id) REFERENCES meals(meal_id)
);

CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    pnr VARCHAR(20) NOT NULL,
    recipient_email VARCHAR(100) NOT NULL,
    event_type ENUM('BOOKING_CONFIRMED', 'WAITING_LIST_ASSIGNED', 'BOOKING_CANCELLED', 'WAITING_LIST_PROMOTED', 'SEAT_ALERT') NOT NULL,
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- MEALS SEED DATA (IN INDIAN RUPEES ₹)
INSERT INTO meals (meal_id, meal_name, meal_type, price, description) VALUES
(1, 'No In-Flight Meal', 'SPECIAL', 0.00, 'Complimentary packaged mineral water on board'),
(2, 'Royal Indian Thali', 'VEG', 350.00, 'Fragrant basmati rice, paneer butter masala, dal makhani, warm rotis & gulab jamun'),
(3, 'South Indian Tiffin Combo', 'VEG', 280.00, 'Steaming idlis, crispy medu vada, masala dosa with sambar and coconut chutney'),
(4, 'Hyderabadi Dum Biryani', 'NON_VEG', 490.00, 'Aromatic basmati rice cooked with spiced tender chicken and mirchi ka salan'),
(5, 'Continental Breakfast Tray', 'NON_VEG', 420.00, 'Fluffy masala omelette, hash browns, chicken sausages, warm croissant & butter'),
(6, 'Asian Superfood Salad Bowl', 'VEG', 380.00, 'Tofu, edamame, crisp greens, roasted almonds, and sesame ginger dressing'),
(7, 'Mutton Rogan Josh Gourmet Platter', 'NON_VEG', 650.00, 'Kashmiri braised mutton with saffron pulao and garlic naan'),
(8, 'Masala Chai & Snack Combo', 'BEVERAGE', 180.00, 'Freshly brewed ginger cardamom tea served with hot samosas & cashew cookies');

-- FLIGHTS SEED DATA (DOMESTIC & INTERNATIONAL IN INDIAN RUPEES ₹)
INSERT INTO flights (flight_id, flight_number, airline_name, flight_type, origin_city, origin_airport, destination_city, destination_airport, departure_time, arrival_time, duration_minutes, economy_fare, business_fare, total_seats, available_seats) VALUES
-- Domestic Routes (Major Indian Metro & Vacation Hubs)
(1, 'AI-502', 'Air India', 'DOMESTIC', 'Delhi', 'DEL', 'Mumbai', 'BOM', '06:00:00', '08:15:00', 135, 4500.00, 14500.00, 30, 28),
(2, '6E-611', 'IndiGo', 'DOMESTIC', 'Bengaluru', 'BLR', 'Delhi', 'DEL', '14:30:00', '17:15:00', 165, 5200.00, 16000.00, 30, 29),
(3, 'UK-825', 'Vistara', 'DOMESTIC', 'Mumbai', 'BOM', 'Goa', 'GOI', '16:00:00', '17:10:00', 70, 3800.00, 11500.00, 30, 27),
(4, 'SG-304', 'SpiceJet', 'DOMESTIC', 'Delhi', 'DEL', 'Bengaluru', 'BLR', '09:15:00', '12:05:00', 170, 4900.00, 15200.00, 30, 30),
(5, '6E-205', 'IndiGo', 'DOMESTIC', 'Kolkata', 'CCU', 'Chennai', 'MAA', '10:45:00', '13:10:00', 145, 4200.00, 13800.00, 30, 30),
(6, 'AI-670', 'Air India', 'DOMESTIC', 'Hyderabad', 'HYD', 'Goa', 'GOI', '11:20:00', '12:40:00', 80, 3500.00, 10800.00, 30, 30),
(7, 'QP-112', 'Akasa Air', 'DOMESTIC', 'Bengaluru', 'BLR', 'Mumbai', 'BOM', '18:10:00', '19:50:00', 100, 3900.00, 12000.00, 30, 30),
(8, 'UK-955', 'Vistara', 'DOMESTIC', 'Delhi', 'DEL', 'Kochi', 'COK', '07:45:00', '11:00:00', 195, 5800.00, 17500.00, 30, 30),

-- International Routes (From India and Global Connectors)
(9, 'EK-501', 'Emirates', 'INTERNATIONAL', 'Mumbai', 'BOM', 'Dubai', 'DXB', '04:30:00', '06:15:00', 255, 21500.00, 68000.00, 30, 26),
(10, 'SQ-503', 'Singapore Airlines', 'INTERNATIONAL', 'Bengaluru', 'BLR', 'Singapore', 'SIN', '23:05:00', '06:10:00', 275, 24500.00, 76000.00, 30, 25),
(11, 'BA-198', 'British Airways', 'INTERNATIONAL', 'Delhi', 'DEL', 'London', 'LHR', '13:20:00', '18:10:00', 560, 48000.00, 142000.00, 30, 28),
(12, 'AI-101', 'Air India', 'INTERNATIONAL', 'Delhi', 'DEL', 'New York', 'JFK', '02:00:00', '07:35:00', 905, 62000.00, 195000.00, 30, 24),
(13, 'QR-573', 'Qatar Airways', 'INTERNATIONAL', 'Delhi', 'DEL', 'Doha', 'DOH', '09:50:00', '11:45:00', 265, 26000.00, 82000.00, 30, 29),
(14, 'LH-755', 'Lufthansa', 'INTERNATIONAL', 'Bengaluru', 'BLR', 'Frankfurt', 'FRA', '03:15:00', '08:50:00', 545, 52000.00, 155000.00, 30, 27),
(15, 'TG-318', 'Thai Airways', 'INTERNATIONAL', 'Mumbai', 'BOM', 'Bangkok', 'BKK', '23:30:00', '05:35:00', 275, 19500.00, 58000.00, 30, 30),
(16, 'AF-225', 'Air France', 'INTERNATIONAL', 'Delhi', 'DEL', 'Paris', 'CDG', '00:35:00', '06:30:00', 565, 49000.00, 148000.00, 30, 28);

-- Populate 30 seats per flight
DELIMITER //
CREATE PROCEDURE PopulateSeats()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 16 DO
        INSERT INTO seats (flight_id, seat_number, seat_class, is_booked) VALUES
        (i, '1A', 'BUSINESS', FALSE), (i, '1B', 'BUSINESS', FALSE), (i, '1C', 'BUSINESS', FALSE), (i, '1D', 'BUSINESS', FALSE),
        (i, '2A', 'BUSINESS', FALSE), (i, '2B', 'BUSINESS', FALSE), (i, '2C', 'BUSINESS', FALSE), (i, '2D', 'BUSINESS', FALSE),
        (i, '3A', 'ECONOMY', FALSE), (i, '3B', 'ECONOMY', FALSE), (i, '3C', 'ECONOMY', FALSE), (i, '3D', 'ECONOMY', FALSE),
        (i, '4A', 'ECONOMY', FALSE), (i, '4B', 'ECONOMY', FALSE), (i, '4C', 'ECONOMY', FALSE), (i, '4D', 'ECONOMY', FALSE),
        (i, '5A', 'ECONOMY', FALSE), (i, '5B', 'ECONOMY', FALSE), (i, '5C', 'ECONOMY', FALSE), (i, '5D', 'ECONOMY', FALSE),
        (i, '6A', 'ECONOMY', FALSE), (i, '6B', 'ECONOMY', FALSE), (i, '6C', 'ECONOMY', FALSE), (i, '6D', 'ECONOMY', FALSE),
        (i, '7A', 'ECONOMY', FALSE), (i, '7B', 'ECONOMY', FALSE), (i, '7C', 'ECONOMY', FALSE), (i, '7D', 'ECONOMY', FALSE),
        (i, '8A', 'ECONOMY', FALSE), (i, '8B', 'ECONOMY', FALSE);
        SET i = i + 1;
    END WHILE;
END //
DELIMITER ;

CALL PopulateSeats();
DROP PROCEDURE IF EXISTS PopulateSeats;

-- Sample Initial Confirmed Booking
INSERT INTO bookings (pnr, flight_id, travel_date, travel_class, contact_name, contact_email, contact_phone, total_amount, status)
VALUES ('SKY-77821', 1, CURDATE() + INTERVAL 5 DAY, 'ECONOMY', 'Aarav Sharma', 'aarav.sharma@example.com', '+91-9876543210', 4850.00, 'CONFIRMED');

INSERT INTO passengers (pnr, full_name, age, gender, id_passport_number, seat_number, meal_id, is_priority, priority_score)
VALUES ('SKY-77821', 'Aarav Sharma', 32, 'Male', 'IND-P9812450', '3A', 2, FALSE, 0);

UPDATE seats SET is_booked = TRUE, booked_pnr = 'SKY-77821' WHERE flight_id = 1 AND seat_number = '3A';

INSERT INTO notifications (pnr, recipient_email, event_type, subject, message)
VALUES ('SKY-77821', 'aarav.sharma@example.com', 'BOOKING_CONFIRMED', 'Skyline Airways: Booking Confirmed (PNR: SKY-77821)',
'Dear Aarav Sharma, your flight AI-502 on Economy Class is CONFIRMED. Assigned seat: 3A. In-flight meal: Royal Indian Thali. Total Fare: ₹4,850.00.');