package com.airline.dao;

import com.airline.config.DbConfig;
import com.airline.model.Notification;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class NotificationDao {
    private static final List<Notification> memoryNotifs = new CopyOnWriteArrayList<>();

    public boolean createNotification(Notification notif) {
        memoryNotifs.add(0, notif);
        String sql = "INSERT INTO notifications (pnr, recipient_email, event_type, subject, message) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, notif.getPnr());
            ps.setString(2, notif.getRecipientEmail());
            ps.setString(3, notif.getEventType());
            ps.setString(4, notif.getSubject());
            ps.setString(5, notif.getMessage());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("[NotificationDao] Notice inserting notification: " + e.getMessage());
            return true;
        }
    }

    public List<Notification> getRecentNotifications(int limit) {
        List<Notification> list = new ArrayList<>();
        String sql = "SELECT * FROM notifications ORDER BY notification_id DESC LIMIT ?";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Notification(
                            rs.getInt("notification_id"),
                            rs.getString("pnr"),
                            rs.getString("recipient_email"),
                            rs.getString("event_type"),
                            rs.getString("subject"),
                            rs.getString("message"),
                            rs.getBoolean("is_read"),
                            rs.getString("created_at")
                    ));
                }
            }
        } catch (Exception e) {
            System.err.println("[NotificationDao] Notice getRecentNotifications: " + e.getMessage());
        }

        if (list.isEmpty()) {
            return memoryNotifs.subList(0, Math.min(limit, memoryNotifs.size()));
        }
        return list;
    }

    public List<Notification> getNotificationsByPnr(String pnr) {
        List<Notification> list = new ArrayList<>();
        String sql = "SELECT * FROM notifications WHERE pnr = ? ORDER BY notification_id DESC";
        try (Connection conn = DbConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, pnr);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Notification(
                            rs.getInt("notification_id"),
                            rs.getString("pnr"),
                            rs.getString("recipient_email"),
                            rs.getString("event_type"),
                            rs.getString("subject"),
                            rs.getString("message"),
                            rs.getBoolean("is_read"),
                            rs.getString("created_at")
                    ));
                }
            }
        } catch (Exception e) {
            System.err.println("[NotificationDao] Error getNotificationsByPnr: " + e.getMessage());
        }

        if (list.isEmpty()) {
            for (Notification n : memoryNotifs) {
                if (n.getPnr().equalsIgnoreCase(pnr)) list.add(n);
            }
        }
        return list;
    }
}