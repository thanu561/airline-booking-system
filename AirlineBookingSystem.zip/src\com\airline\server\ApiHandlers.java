package com.airline.server;

import com.airline.dao.MealDao;
import com.airline.model.Booking;
import com.airline.model.Flight;
import com.airline.model.Notification;
import com.airline.model.Passenger;
import com.airline.model.Seat;
import com.airline.service.BookingService;
import com.airline.service.FlightService;
import com.airline.service.NotificationService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ApiHandlers {
    private static final FlightService flightService = new FlightService();
    private static final BookingService bookingService = new BookingService();
    private static final MealDao mealDao = new MealDao();
    private static final NotificationService notificationService = new NotificationService();

    // =========================================================================
    // 1. FLIGHTS API: Search, Filter, Sort (using DSA Sorter & Search Engine)
    // =========================================================================
    public static class FlightsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 204, "");
                return;
            }

            Map<String, String> params = parseQueryParams(exchange.getRequestURI().getQuery());
            String origin = params.getOrDefault("origin", "");
            String dest = params.getOrDefault("destination", "");
            String type = params.getOrDefault("type", "");
            String travelClass = params.getOrDefault("class", "ECONOMY");
            String sortBy = params.getOrDefault("sort", "price");
            boolean ascending = !"desc".equalsIgnoreCase(params.get("order"));
            Double maxFare = null;
            if (params.containsKey("budget") && !params.get("budget").isEmpty()) {
                try {
                    maxFare = Double.parseDouble(params.get("budget"));
                } catch (Exception ignored) {}
            }

            List<Flight> flights = flightService.searchFlights(origin, dest, type, travelClass, sortBy, ascending, maxFare);
            String json = JsonUtil.listToJson(flights);
            sendJsonResponse(exchange, 200, json);
        }
    }

    // =========================================================================
    // 2. DSA BINARY SEARCH DEMO API
    // =========================================================================
    public static class BinarySearchHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 204, "");
                return;
            }

            Map<String, String> params = parseQueryParams(exchange.getRequestURI().getQuery());
            if (params.containsKey("id")) {
                int id = Integer.parseInt(params.get("id"));
                Flight f = flightService.findFlightByBinarySearch(id);
                Map<String, Object> resp = new HashMap<>();
                resp.put("algorithm", "Binary Search O(log N)");
                resp.put("targetFlightId", id);
                resp.put("found", f != null);
                resp.put("flight", f);
                sendJsonResponse(exchange, 200, JsonUtil.mapToJson(resp));
            } else if (params.containsKey("budget")) {
                double budget = Double.parseDouble(params.get("budget"));
                List<Flight> list = flightService.findFlightsUnderBudgetBinarySearch(budget);
                Map<String, Object> resp = new HashMap<>();
                resp.put("algorithm", "Binary Search with Fare Ceiling O(log N)");
                resp.put("maxBudget", budget);
                resp.put("matchesCount", list.size());
                resp.put("flights", list);
                sendJsonResponse(exchange, 200, JsonUtil.mapToJson(resp));
            } else {
                sendJsonResponse(exchange, 400, "{\"error\":\"Provide 'id' or 'budget' parameter\"}");
            }
        }
    }

    // =========================================================================
    // 3. SEATS API: Returns visual seat map
    // =========================================================================
    public static class SeatsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 204, "");
                return;
            }

            Map<String, String> params = parseQueryParams(exchange.getRequestURI().getQuery());
            int flightId = 1;
            if (params.containsKey("flightId")) {
                try {
                    flightId = Integer.parseInt(params.get("flightId"));
                } catch (Exception ignored) {}
            }

            List<Seat> seats = flightService.getFlightSeats(flightId);
            sendJsonResponse(exchange, 200, JsonUtil.listToJson(seats));
        }
    }

    // =========================================================================
    // 4. MEALS API: Fixed prices menu
    // =========================================================================
    public static class MealsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 204, "");
                return;
            }
            sendJsonResponse(exchange, 200, JsonUtil.listToJson(mealDao.getAllMeals()));
        }
    }

    // =========================================================================
    // 5. BOOKING TRANSACTION API
    // =========================================================================
    public static class BookHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 204, "");
                return;
            }

            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJsonResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}");
                return;
            }

            String body = readRequestBody(exchange);
            Map<String, String> json = JsonUtil.parseSimpleJson(body);

            try {
                int flightId = Integer.parseInt(json.getOrDefault("flightId", "1"));
                String travelDate = json.getOrDefault("travelDate", "2026-09-10");
                String travelClass = json.getOrDefault("travelClass", "ECONOMY");
                String contactName = json.getOrDefault("contactName", "Passenger");
                String contactEmail = json.getOrDefault("contactEmail", "guest@example.com");
                String contactPhone = json.getOrDefault("contactPhone", "+1-000-000-0000");

                Booking booking = new Booking();
                booking.setFlightId(flightId);
                booking.setTravelDate(travelDate);
                booking.setTravelClass(travelClass);
                booking.setContactName(contactName);
                booking.setContactEmail(contactEmail);
                booking.setContactPhone(contactPhone);

                // Passenger details
                List<Passenger> passengers = new ArrayList<>();
                Passenger p = new Passenger();
                p.setFullName(json.getOrDefault("fullName", contactName));
                p.setAge(Integer.parseInt(json.getOrDefault("age", "30")));
                p.setGender(json.getOrDefault("gender", "Other"));
                p.setIdPassportNumber(json.getOrDefault("idPassportNumber", "DOC-PENDING"));
                p.setSeatNumber(json.get("seatNumber"));
                if (json.containsKey("mealId") && !json.get("mealId").isEmpty()) {
                    p.setMealId(Integer.parseInt(json.get("mealId")));
                }
                boolean isPriority = "true".equalsIgnoreCase(json.get("isPriority")) || p.getAge() >= 60;
                p.setPriority(isPriority);
                passengers.add(p);

                Map<String, Object> result = bookingService.processBooking(booking, passengers, true);
                sendJsonResponse(exchange, 200, JsonUtil.mapToJson(result));
            } catch (Exception e) {
                e.printStackTrace();
                sendJsonResponse(exchange, 500, "{\"success\":false,\"message\":\"Error processing booking: " + e.getMessage() + "\"}");
            }
        }
    }

    // =========================================================================
    // 6. CANCELLATION API
    // =========================================================================
    public static class CancelHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 204, "");
                return;
            }

            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJsonResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}");
                return;
            }

            String body = readRequestBody(exchange);
            Map<String, String> json = JsonUtil.parseSimpleJson(body);
            String pnr = json.get("pnr");

            if (pnr == null || pnr.trim().isEmpty()) {
                sendJsonResponse(exchange, 400, "{\"success\":false,\"message\":\"PNR is required for cancellation\"}");
                return;
            }

            Map<String, Object> result = bookingService.cancelBooking(pnr.trim());
            sendJsonResponse(exchange, 200, JsonUtil.mapToJson(result));
        }
    }

    // =========================================================================
    // 7. BOOKING HISTORY & PNR LOOKUP API
    // =========================================================================
    public static class HistoryHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 204, "");
                return;
            }

            Map<String, String> params = parseQueryParams(exchange.getRequestURI().getQuery());
            String query = params.getOrDefault("query", "");

            if (query.isEmpty()) {
                sendJsonResponse(exchange, 200, "[]");
                return;
            }

            List<Booking> bookings = bookingService.searchHistory(query);
            sendJsonResponse(exchange, 200, JsonUtil.listToJson(bookings));
        }
    }

    // =========================================================================
    // 8. NOTIFICATIONS API
    // =========================================================================
    public static class NotificationsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 204, "");
                return;
            }

            Map<String, String> params = parseQueryParams(exchange.getRequestURI().getQuery());
            if (params.containsKey("pnr")) {
                List<Notification> notifs = notificationService.getNotificationsByPnr(params.get("pnr"));
                sendJsonResponse(exchange, 200, JsonUtil.listToJson(notifs));
            } else {
                int limit = 15;
                if (params.containsKey("limit")) {
                    try {
                        limit = Integer.parseInt(params.get("limit"));
                    } catch (Exception ignored) {}
                }
                List<Notification> notifs = notificationService.getRecentNotifications(limit);
                sendJsonResponse(exchange, 200, JsonUtil.listToJson(notifs));
            }
        }
    }

    // =========================================================================
    // 9. DSA INSPECTOR & STATS API
    // =========================================================================
    public static class DsaStatsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 204, "");
                return;
            }
            Map<String, Object> metrics = bookingService.getDsaInspectionMetrics();
            sendJsonResponse(exchange, 200, JsonUtil.mapToJson(metrics));
        }
    }

    // =========================================================================
    // HTTP UTILITY HELPERS
    // =========================================================================
    public static void addCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    }

    public static void sendJsonResponse(HttpExchange exchange, int statusCode, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    public static void sendResponse(HttpExchange exchange, int statusCode, String response) throws IOException {
        byte[] bytes = response.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    public static String readRequestBody(HttpExchange exchange) throws IOException {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            return sb.toString();
        }
    }

    public static Map<String, String> parseQueryParams(String query) {
        Map<String, String> map = new HashMap<>();
        if (query == null || query.isEmpty()) return map;
        String[] pairs = query.split("&");
        for (String pair : pairs) {
            int idx = pair.indexOf("=");
            try {
                if (idx > 0) {
                    String key = java.net.URLDecoder.decode(pair.substring(0, idx), "UTF-8");
                    String val = java.net.URLDecoder.decode(pair.substring(idx + 1), "UTF-8");
                    map.put(key, val);
                } else {
                    map.put(java.net.URLDecoder.decode(pair, "UTF-8"), "");
                }
            } catch (Exception ignored) {}
        }
        return map;
    }
}